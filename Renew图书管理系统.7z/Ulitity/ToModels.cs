﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ulitity
{
    public static class ToModels
    {
        public static TModel DataRowToModel<TModel>(this DataRow dr)
        {
            Type type = typeof(TModel);
            //这一句就是实例化，相当于new
            TModel model = (TModel)Activator.CreateInstance(type);
            foreach (var items in type.GetProperties())
            {
                //这里相当于
                //usersApparisalBases.Add(ToModel(dr));
                //usersApparisalBases.Id = (int)dr["ID"];
                items.SetValue(model, dr[items.Name]);
            }
            return model;
        }
    }
}
