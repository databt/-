﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//namespace Ulitity
//{
//    //偷懒工厂：制造多窗体的工厂，实现多窗体的切换
//    //每个窗体切换都要先关闭一个，再去打开切换的窗体
//    public class FormFactory
//    {

//        private static List<Form> formlist = new List<Form>();
//        private static List<Type> types;

//        static FormFactory()
//        {
//            Assembly assembly = Assembly.LoadFrom("Renew_Library_System.exe");
//            types = assembly.GetTypes().ToList();
//        }
//        public static Form CreateForm(string formName, object param1 = null,object param2 = null,object param3 = null)
//        {//这里param=null是表示可以没有，相当于重载
//            FormHideAll();
//            //formName = formName == null ? "FormNone" : formName;
//            formName = formName ?? "FormNone";
//            Form form = formlist.Find(m => m.Name == formName);
//            if (form == null)
//            {
//                Type type = types.Find(m => m.Name == formName);
//                if (HasThreeParameterConstructor(type))
//                {
//                    form = (Form)Activator.CreateInstance(type, param1,param2,param3);
//                }
//                else if(HasTwoParameterConstructor(type))
//                {
//                    form = (Form)Activator.CreateInstance(type, param1, param2);
//                }
//                else if (HasOneParameterConstructor(type))
//                {
//                    form = (Form)Activator.CreateInstance(type, param1);
//                }
//                else
//                {
//                    form = (Form)Activator.CreateInstance(type);
//                }
//                formlist.Add(form);
//            }
//            else
//            {
//                Type type = types.Find(m => m.Name == formName);
//                form = (Form)Activator.CreateInstance(type, param1, param2, param3);
//            }
//            return form;
//        }

//        private static bool HasOneParameterConstructor(Type type)
//        {
//            return type.GetConstructors().Any(c => c.GetParameters().Length == 3
//&& c.GetParameters()[0].ParameterType == typeof(string));
//        }

//        private static bool HasTwoParameterConstructor(Type type)
//        {
//            return type.GetConstructors().Any(c => c.GetParameters().Length == 3
//&& c.GetParameters()[0].ParameterType == typeof(string) &&
//c.GetParameters()[1].ParameterType == typeof(int));
//        }


//        private static bool HasThreeParameterConstructor(Type type)
//        {
//            // 检查给定的类型是否有一个构造函数，该构造函数接受string、int、string类型的参数。
//            return type.GetConstructors().Any(c => c.GetParameters().Length == 3 
//            && c.GetParameters()[0].ParameterType == typeof(string) &&
//            c.GetParameters()[1].ParameterType == typeof(int)
//            && c.GetParameters()[2].ParameterType == typeof(string));
//        }

//        //仓储，一次性把窗体都隐藏
//        public static void FormHideAll()
//        {
//            foreach (Form form in formlist)
//            {
//                form.Hide();
//            }
//        }
//    }
//}
// 在FormFactory类的构造函数中，使用了Assembly.LoadFrom方法加载了一个外部程序集，但是没有对加载过程中可能出现的异常进行处理。
// 建议使用try-catch块来捕获异常并进行处理。
//在CreateForm方法中，使用了formlist.Find方法来查找已经创建的窗体，但是这个方法的时间复杂度是O(n)，会随着窗体数量的增加而增加查找的时间。
//建议使用Dictionary<string, Form>来存储已经创建的窗体，以窗体名称作为键，可以将查找时间复杂度降低到O(1)。
//在CreateForm方法中，当找到已经创建的窗体时，又使用了types.Find方法来查找窗体的类型，这个操作是多余的，可以直接使用已经找到的窗体类型来创建新的窗体。
//在HasOneParameterConstructor和HasTwoParameterConstructor方法中，判断构造函数是否存在时，使用了错误的参数个数和参数类型进行判断。应该根据实际的构造函数参数个数和类型进行判断。
//在HasThreeParameterConstructor方法中，判断构造函数是否存在时，使用了错误的参数个数和参数类型进行判断。应该根据实际的构造函数参数个数和类型进行判断。
//在FormHideAll方法中，隐藏窗体时使用了form.Hide方法，但是没有考虑到窗体可能已经被关闭的情况。建议在隐藏窗体之前先判断窗体的状态，如果窗体已经被关闭，则不需要再隐藏.
namespace Ulitity
{
    //偷懒工厂：制造多窗体的工厂，实现多窗体的切换
    //每个窗体切换都要先关闭一个，再去打开切换的窗体
    public class FormFactory
    {
        private static Dictionary<string, Form> formlist = new Dictionary<string, Form>();
        private static List<Type> types;

        static FormFactory()
        {
            try
            {
                Assembly assembly = Assembly.LoadFrom("Renew_Library_System.exe");
                types = assembly.GetTypes().ToList();
            }
            catch (Exception ex)
            {
                // 处理加载程序集异常的逻辑
                Console.WriteLine("加载程序集异常：" + ex.Message);
            }
        }

        public static Form CreateForm(string formName, object param1 = null, object param2 = null, object param3 = null)
        {
            FormHideAll();
            formName = formName ?? "FormNone";
            Form form;
            if (!formlist.TryGetValue(formName, out form))
            {
                Type type = types.Find(m => m.Name == formName);
                if (type != null)
                {
                    if (HasThreeParameterConstructor(type))
                    {
                        form = (Form)Activator.CreateInstance(type, param1, param2, param3);
                    }
                    else if (HasTwoParameterConstructor(type))
                    {
                        form = (Form)Activator.CreateInstance(type, param1, param2);
                    }
                    else if (HasOneParameterConstructorString(type))
                    {
                        form = (Form)Activator.CreateInstance(type, param1);
                    }
                    else if (HasOneParameterConstructorInt(type))
                    {
                        form = (Form)Activator.CreateInstance(type, param2);
                    }
                    else
                    {
                        form = (Form)Activator.CreateInstance(type);
                    }
                    formlist.Add(formName, form);
                }
                else
                {
                    Console.WriteLine("未找到窗体类型：" + formName);
                }
            }
            else
            {
                Console.WriteLine("窗体已经创建：" + formName);
            }
            return form;
        }
        //以下函数都是创建窗体时写入参数，根据写入参数的类型需要添加函数
        private static bool HasOneParameterConstructorString(Type type)
        {
            return type.GetConstructors().Any(c => c.GetParameters().Length == 1
                && c.GetParameters()[0].ParameterType == typeof(string));
        }
        private static bool HasOneParameterConstructorInt(Type type)
        {
            return type.GetConstructors().Any(c => c.GetParameters().Length == 1
                && c.GetParameters()[0].ParameterType == typeof(int));
        }

        private static bool HasTwoParameterConstructor(Type type)
        {
            return type.GetConstructors().Any(c => c.GetParameters().Length == 2
                && c.GetParameters()[0].ParameterType == typeof(string)
                && c.GetParameters()[1].ParameterType == typeof(int));
        }

        private static bool HasThreeParameterConstructor(Type type)
        {
            return type.GetConstructors().Any(c => c.GetParameters().Length == 3
                && c.GetParameters()[0].ParameterType == typeof(string)
                && c.GetParameters()[1].ParameterType == typeof(int)
                && c.GetParameters()[2].ParameterType == typeof(string));
        }

        public static void FormRemove(string formname)
        {
            formlist.Remove(formname);
        }

        //仓储，一次性把窗体都隐藏
        public static void FormHideAll()
        {
            foreach (Form form in formlist.Values)
            {
                if (form.IsDisposed)
                {
                    continue;
                }
                form.Hide();
            }
        }
    }
}