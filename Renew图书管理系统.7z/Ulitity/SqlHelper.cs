﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ulitity
{
    public class SqlHelper
    {
        //连接字符串
        public static string ConStr { get; set; }
        //获取数据库的数据
        public static DataTable ExecuteTable(string cmdText, params SqlParameter[] sqlParameters)
        {
            using (SqlConnection con = new SqlConnection(ConStr))
            {
                con.Open();
                //仓库管家
                SqlCommand cmd = new SqlCommand(cmdText, con);
                cmd.Parameters.AddRange(sqlParameters);
                //推车
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
                //货车
                DataSet ds = new DataSet();
                //货车满载，返回第一个集装箱
                sqlDataAdapter.Fill(ds);
                return ds.Tables[0];
            }
        }
        //实现在数据库增删改的操作
        public static int ExecuteNonQuery(string cmdText, params SqlParameter[] sqlParameter)
        {
            using (SqlConnection con = new SqlConnection(ConStr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(cmdText, con);
                cmd.Parameters.AddRange(sqlParameter);
                //返回受影响（增删改）的行数
                int rows = cmd.ExecuteNonQuery();
                //if (rows <= 0)
                //{
                //    throw new Exception("数据库操作失败");
                //}
                return rows;
            }
        }
    }
}
