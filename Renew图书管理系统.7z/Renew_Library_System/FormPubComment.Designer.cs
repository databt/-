﻿namespace Renew_Library_System
{
    partial class FormPubComment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Pub_btn = new System.Windows.Forms.Button();
            this.Bname_tbx = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.num_tbx = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comment_rtb = new System.Windows.Forms.RichTextBox();
            this.close_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "书名";
            // 
            // Pub_btn
            // 
            this.Pub_btn.Location = new System.Drawing.Point(202, 587);
            this.Pub_btn.Name = "Pub_btn";
            this.Pub_btn.Size = new System.Drawing.Size(147, 48);
            this.Pub_btn.TabIndex = 1;
            this.Pub_btn.Text = "发表";
            this.Pub_btn.UseVisualStyleBackColor = true;
            this.Pub_btn.Click += new System.EventHandler(this.Pub_btn_Click);
            // 
            // Bname_tbx
            // 
            this.Bname_tbx.Location = new System.Drawing.Point(109, 40);
            this.Bname_tbx.Name = "Bname_tbx";
            this.Bname_tbx.ReadOnly = true;
            this.Bname_tbx.Size = new System.Drawing.Size(205, 38);
            this.Bname_tbx.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "评论";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 492);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 31);
            this.label3.TabIndex = 4;
            this.label3.Text = "评分";
            // 
            // num_tbx
            // 
            this.num_tbx.Location = new System.Drawing.Point(109, 489);
            this.num_tbx.Name = "num_tbx";
            this.num_tbx.Size = new System.Drawing.Size(64, 38);
            this.num_tbx.TabIndex = 5;
            this.num_tbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.num_tbx_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(179, 492);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 31);
            this.label4.TabIndex = 6;
            this.label4.Text = "/5";
            // 
            // comment_rtb
            // 
            this.comment_rtb.Location = new System.Drawing.Point(109, 127);
            this.comment_rtb.Name = "comment_rtb";
            this.comment_rtb.Size = new System.Drawing.Size(625, 323);
            this.comment_rtb.TabIndex = 7;
            this.comment_rtb.Text = "";
            this.comment_rtb.TextChanged += new System.EventHandler(this.comment_rtb_TextChanged);
            // 
            // close_btn
            // 
            this.close_btn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.close_btn.Location = new System.Drawing.Point(390, 587);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(147, 48);
            this.close_btn.TabIndex = 8;
            this.close_btn.Text = "关闭";
            this.close_btn.UseVisualStyleBackColor = true;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // FormPubComment
            // 
            this.AcceptButton = this.Pub_btn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CancelButton = this.close_btn;
            this.ClientSize = new System.Drawing.Size(781, 680);
            this.Controls.Add(this.close_btn);
            this.Controls.Add(this.comment_rtb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.num_tbx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Bname_tbx);
            this.Controls.Add(this.Pub_btn);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FormPubComment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormPubComment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Pub_btn;
        private System.Windows.Forms.TextBox Bname_tbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox num_tbx;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox comment_rtb;
        private System.Windows.Forms.Button close_btn;
    }
}