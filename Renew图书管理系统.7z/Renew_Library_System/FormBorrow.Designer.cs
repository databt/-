﻿namespace Renew_Library_System
{
    partial class FormBorrow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.type_cbx = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Refer_btn = new System.Windows.Forms.Button();
            this.BookName_tbx = new System.Windows.Forms.TextBox();
            this.Borrow_btn = new System.Windows.Forms.Button();
            this.Return_btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.UBook_dgv = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Author = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Publisher = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TypeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Introduce = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BorrowCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PBdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.查看简介ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PubComment_btn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UBook_dgv)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.PubComment_btn);
            this.groupBox1.Controls.Add(this.type_cbx);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Refer_btn);
            this.groupBox1.Controls.Add(this.BookName_tbx);
            this.groupBox1.Controls.Add(this.Borrow_btn);
            this.groupBox1.Controls.Add(this.Return_btn);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.Color.Coral;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(886, 134);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // type_cbx
            // 
            this.type_cbx.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.type_cbx.FormattingEnabled = true;
            this.type_cbx.Location = new System.Drawing.Point(346, 30);
            this.type_cbx.Margin = new System.Windows.Forms.Padding(2);
            this.type_cbx.Name = "type_cbx";
            this.type_cbx.Size = new System.Drawing.Size(150, 35);
            this.type_cbx.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(250, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 27);
            this.label1.TabIndex = 14;
            this.label1.Text = "图书类型";
            // 
            // Refer_btn
            // 
            this.Refer_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Refer_btn.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Refer_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Refer_btn.Location = new System.Drawing.Point(534, 24);
            this.Refer_btn.Margin = new System.Windows.Forms.Padding(2);
            this.Refer_btn.Name = "Refer_btn";
            this.Refer_btn.Size = new System.Drawing.Size(138, 41);
            this.Refer_btn.TabIndex = 13;
            this.Refer_btn.Text = "查询";
            this.Refer_btn.UseVisualStyleBackColor = true;
            this.Refer_btn.Click += new System.EventHandler(this.Refer_btn_Click);
            // 
            // BookName_tbx
            // 
            this.BookName_tbx.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BookName_tbx.Location = new System.Drawing.Point(81, 30);
            this.BookName_tbx.Margin = new System.Windows.Forms.Padding(2);
            this.BookName_tbx.Name = "BookName_tbx";
            this.BookName_tbx.Size = new System.Drawing.Size(150, 34);
            this.BookName_tbx.TabIndex = 12;
            // 
            // Borrow_btn
            // 
            this.Borrow_btn.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Borrow_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Borrow_btn.Location = new System.Drawing.Point(10, 82);
            this.Borrow_btn.Margin = new System.Windows.Forms.Padding(2);
            this.Borrow_btn.Name = "Borrow_btn";
            this.Borrow_btn.Size = new System.Drawing.Size(156, 41);
            this.Borrow_btn.TabIndex = 11;
            this.Borrow_btn.Text = "租借图书";
            this.Borrow_btn.UseVisualStyleBackColor = true;
            this.Borrow_btn.Click += new System.EventHandler(this.Borrow_btn_Click);
            // 
            // Return_btn
            // 
            this.Return_btn.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Return_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Return_btn.Location = new System.Drawing.Point(171, 82);
            this.Return_btn.Margin = new System.Windows.Forms.Padding(2);
            this.Return_btn.Name = "Return_btn";
            this.Return_btn.Size = new System.Drawing.Size(156, 41);
            this.Return_btn.TabIndex = 10;
            this.Return_btn.Text = "归还图书";
            this.Return_btn.UseVisualStyleBackColor = true;
            this.Return_btn.Click += new System.EventHandler(this.Return_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(5, 33);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 27);
            this.label2.TabIndex = 9;
            this.label2.Text = "图书名";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.UBook_dgv);
            this.groupBox2.Location = new System.Drawing.Point(12, 140);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(886, 529);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // UBook_dgv
            // 
            this.UBook_dgv.AllowUserToAddRows = false;
            this.UBook_dgv.AllowUserToDeleteRows = false;
            this.UBook_dgv.BackgroundColor = System.Drawing.Color.MediumAquamarine;
            this.UBook_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UBook_dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.BookName,
            this.Author,
            this.Publisher,
            this.TypeName,
            this.Introduce,
            this.Price,
            this.Num,
            this.BorrowCount,
            this.PBdate});
            this.UBook_dgv.ContextMenuStrip = this.contextMenuStrip1;
            this.UBook_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.UBook_dgv.Location = new System.Drawing.Point(3, 21);
            this.UBook_dgv.Name = "UBook_dgv";
            this.UBook_dgv.ReadOnly = true;
            this.UBook_dgv.RowHeadersWidth = 51;
            this.UBook_dgv.RowTemplate.Height = 27;
            this.UBook_dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.UBook_dgv.Size = new System.Drawing.Size(880, 505);
            this.UBook_dgv.TabIndex = 0;
            this.UBook_dgv.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.UBook_dgv_CellMouseDown);
            this.UBook_dgv.MouseDown += new System.Windows.Forms.MouseEventHandler(this.UBook_dgv_MouseDown);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "编号";
            this.ID.MinimumWidth = 6;
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 80;
            // 
            // BookName
            // 
            this.BookName.DataPropertyName = "Name";
            this.BookName.HeaderText = "书名";
            this.BookName.MinimumWidth = 6;
            this.BookName.Name = "BookName";
            this.BookName.ReadOnly = true;
            this.BookName.Width = 125;
            // 
            // Author
            // 
            this.Author.DataPropertyName = "Author";
            this.Author.HeaderText = "作者";
            this.Author.MinimumWidth = 6;
            this.Author.Name = "Author";
            this.Author.ReadOnly = true;
            this.Author.Width = 125;
            // 
            // Publisher
            // 
            this.Publisher.DataPropertyName = "Publisher";
            this.Publisher.HeaderText = "出版社";
            this.Publisher.MinimumWidth = 6;
            this.Publisher.Name = "Publisher";
            this.Publisher.ReadOnly = true;
            this.Publisher.Width = 125;
            // 
            // TypeName
            // 
            this.TypeName.DataPropertyName = "typeName";
            this.TypeName.HeaderText = "书籍类型";
            this.TypeName.MinimumWidth = 6;
            this.TypeName.Name = "TypeName";
            this.TypeName.ReadOnly = true;
            this.TypeName.Width = 125;
            // 
            // Introduce
            // 
            this.Introduce.DataPropertyName = "Introduce";
            this.Introduce.HeaderText = "书籍简介";
            this.Introduce.MinimumWidth = 6;
            this.Introduce.Name = "Introduce";
            this.Introduce.ReadOnly = true;
            this.Introduce.Width = 125;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            dataGridViewCellStyle1.Format = "C2";
            dataGridViewCellStyle1.NullValue = null;
            this.Price.DefaultCellStyle = dataGridViewCellStyle1;
            this.Price.HeaderText = "价格";
            this.Price.MinimumWidth = 6;
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 80;
            // 
            // Num
            // 
            this.Num.DataPropertyName = "Num";
            this.Num.HeaderText = "数量";
            this.Num.MinimumWidth = 6;
            this.Num.Name = "Num";
            this.Num.ReadOnly = true;
            this.Num.Width = 80;
            // 
            // BorrowCount
            // 
            this.BorrowCount.DataPropertyName = "BorrowCount";
            this.BorrowCount.HeaderText = "借出数量";
            this.BorrowCount.MinimumWidth = 6;
            this.BorrowCount.Name = "BorrowCount";
            this.BorrowCount.ReadOnly = true;
            this.BorrowCount.Width = 80;
            // 
            // PBdate
            // 
            this.PBdate.DataPropertyName = "PBdate";
            dataGridViewCellStyle2.Format = "D";
            dataGridViewCellStyle2.NullValue = null;
            this.PBdate.DefaultCellStyle = dataGridViewCellStyle2;
            this.PBdate.HeaderText = "添加日期";
            this.PBdate.MinimumWidth = 6;
            this.PBdate.Name = "PBdate";
            this.PBdate.ReadOnly = true;
            this.PBdate.Width = 125;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查看简介ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(139, 28);
            // 
            // 查看简介ToolStripMenuItem
            // 
            this.查看简介ToolStripMenuItem.Name = "查看简介ToolStripMenuItem";
            this.查看简介ToolStripMenuItem.Size = new System.Drawing.Size(138, 24);
            this.查看简介ToolStripMenuItem.Text = "查看简介";
            this.查看简介ToolStripMenuItem.Click += new System.EventHandler(this.查看简介ToolStripMenuItem_Click);
            // 
            // PubComment_btn
            // 
            this.PubComment_btn.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PubComment_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.PubComment_btn.Location = new System.Drawing.Point(346, 82);
            this.PubComment_btn.Margin = new System.Windows.Forms.Padding(2);
            this.PubComment_btn.Name = "PubComment_btn";
            this.PubComment_btn.Size = new System.Drawing.Size(156, 41);
            this.PubComment_btn.TabIndex = 16;
            this.PubComment_btn.Text = "发表评论";
            this.PubComment_btn.UseVisualStyleBackColor = true;
            this.PubComment_btn.Click += new System.EventHandler(this.PubComment_btn_Click);
            // 
            // FormBorrow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(905, 681);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormBorrow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormBorrow";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormBorrow_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.UBook_dgv)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox type_cbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Refer_btn;
        private System.Windows.Forms.TextBox BookName_tbx;
        private System.Windows.Forms.Button Borrow_btn;
        private System.Windows.Forms.Button Return_btn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView UBook_dgv;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 查看简介ToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Author;
        private System.Windows.Forms.DataGridViewTextBoxColumn Publisher;
        private System.Windows.Forms.DataGridViewTextBoxColumn TypeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Introduce;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Num;
        private System.Windows.Forms.DataGridViewTextBoxColumn BorrowCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn PBdate;
        private System.Windows.Forms.Button PubComment_btn;
    }
}