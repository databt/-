﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormNewsMana : Form
    {
        public FormNewsMana()
        {
            InitializeComponent();
        }

        private void FormNewsMana_Load(object sender, EventArgs e)
        {
            bingdgv();
        }

        private void bingdgv()
        {
            DateTime dt = dateTimePicker1.Value.Date;
            Feedback_dgv.DataSource = Feedback.GetListAllJoinFeedback().FindAll(
                m => m.Time == dt);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bingdgv();
        }
    }
}
