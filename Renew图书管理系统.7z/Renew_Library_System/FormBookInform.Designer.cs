﻿namespace Renew_Library_System
{
    partial class FormBookInform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Book_dgv = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.add_tsm = new System.Windows.Forms.ToolStripMenuItem();
            this.edit_tsm = new System.Windows.Forms.ToolStripMenuItem();
            this.down_tsm = new System.Windows.Forms.ToolStripMenuItem();
            this.up_tsm = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.down_check = new System.Windows.Forms.CheckBox();
            this.start_btn = new System.Windows.Forms.Button();
            this.type_cbx = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bookname_tbx = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Author = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Publisher = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TypeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PBdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Introduce = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BorrowCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IsDel = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Book_dgv)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Book_dgv
            // 
            this.Book_dgv.AllowUserToAddRows = false;
            this.Book_dgv.AllowUserToDeleteRows = false;
            this.Book_dgv.BackgroundColor = System.Drawing.Color.MediumAquamarine;
            this.Book_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Book_dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.BookName,
            this.Author,
            this.Publisher,
            this.TypeName,
            this.PBdate,
            this.Price,
            this.Num,
            this.Introduce,
            this.BorrowCount,
            this.IsDel});
            this.Book_dgv.ContextMenuStrip = this.contextMenuStrip1;
            this.Book_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Book_dgv.Location = new System.Drawing.Point(3, 21);
            this.Book_dgv.Name = "Book_dgv";
            this.Book_dgv.ReadOnly = true;
            this.Book_dgv.RowHeadersWidth = 51;
            this.Book_dgv.RowTemplate.Height = 27;
            this.Book_dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Book_dgv.Size = new System.Drawing.Size(865, 462);
            this.Book_dgv.TabIndex = 0;
            this.Book_dgv.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Book_dgv_CellMouseDown);
            this.Book_dgv.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Book_dgv_MouseDown);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.add_tsm,
            this.edit_tsm,
            this.down_tsm,
            this.up_tsm});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(139, 100);
            // 
            // add_tsm
            // 
            this.add_tsm.Name = "add_tsm";
            this.add_tsm.Size = new System.Drawing.Size(138, 24);
            this.add_tsm.Text = "添加图书";
            this.add_tsm.Click += new System.EventHandler(this.add_tsm_Click);
            // 
            // edit_tsm
            // 
            this.edit_tsm.Name = "edit_tsm";
            this.edit_tsm.Size = new System.Drawing.Size(138, 24);
            this.edit_tsm.Text = "修改图书";
            this.edit_tsm.Click += new System.EventHandler(this.edit_tsm_Click);
            // 
            // down_tsm
            // 
            this.down_tsm.Name = "down_tsm";
            this.down_tsm.Size = new System.Drawing.Size(138, 24);
            this.down_tsm.Text = "下架图书";
            this.down_tsm.Click += new System.EventHandler(this.down_tsm_Click);
            // 
            // up_tsm
            // 
            this.up_tsm.Name = "up_tsm";
            this.up_tsm.Size = new System.Drawing.Size(138, 24);
            this.up_tsm.Text = "上架图书";
            this.up_tsm.Click += new System.EventHandler(this.up_tsm_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.down_check);
            this.groupBox1.Controls.Add(this.start_btn);
            this.groupBox1.Controls.Add(this.type_cbx);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.bookname_tbx);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(12, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(871, 76);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "图书查询";
            // 
            // down_check
            // 
            this.down_check.AutoSize = true;
            this.down_check.Location = new System.Drawing.Point(574, 39);
            this.down_check.Name = "down_check";
            this.down_check.Size = new System.Drawing.Size(114, 31);
            this.down_check.TabIndex = 5;
            this.down_check.Text = "下架图书";
            this.down_check.UseVisualStyleBackColor = true;
            // 
            // start_btn
            // 
            this.start_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.start_btn.Location = new System.Drawing.Point(701, 35);
            this.start_btn.Name = "start_btn";
            this.start_btn.Size = new System.Drawing.Size(145, 36);
            this.start_btn.TabIndex = 4;
            this.start_btn.Text = "查询";
            this.start_btn.UseVisualStyleBackColor = true;
            this.start_btn.Click += new System.EventHandler(this.start_btn_Click);
            // 
            // type_cbx
            // 
            this.type_cbx.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.type_cbx.FormattingEnabled = true;
            this.type_cbx.Location = new System.Drawing.Point(351, 37);
            this.type_cbx.Name = "type_cbx";
            this.type_cbx.Size = new System.Drawing.Size(183, 35);
            this.type_cbx.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(293, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 27);
            this.label2.TabIndex = 2;
            this.label2.Text = "类型";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(43, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "书名";
            // 
            // bookname_tbx
            // 
            this.bookname_tbx.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookname_tbx.Location = new System.Drawing.Point(101, 37);
            this.bookname_tbx.Name = "bookname_tbx";
            this.bookname_tbx.Size = new System.Drawing.Size(171, 34);
            this.bookname_tbx.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.Book_dgv);
            this.groupBox2.Location = new System.Drawing.Point(12, 85);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(871, 486);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "编号";
            this.ID.MinimumWidth = 6;
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 80;
            // 
            // BookName
            // 
            this.BookName.DataPropertyName = "Name";
            this.BookName.HeaderText = "书名";
            this.BookName.MinimumWidth = 6;
            this.BookName.Name = "BookName";
            this.BookName.ReadOnly = true;
            this.BookName.Width = 125;
            // 
            // Author
            // 
            this.Author.DataPropertyName = "Author";
            this.Author.HeaderText = "作者";
            this.Author.MinimumWidth = 6;
            this.Author.Name = "Author";
            this.Author.ReadOnly = true;
            this.Author.Width = 125;
            // 
            // Publisher
            // 
            this.Publisher.DataPropertyName = "Publisher";
            this.Publisher.HeaderText = "出版社";
            this.Publisher.MinimumWidth = 6;
            this.Publisher.Name = "Publisher";
            this.Publisher.ReadOnly = true;
            this.Publisher.Width = 125;
            // 
            // TypeName
            // 
            this.TypeName.DataPropertyName = "typeName";
            this.TypeName.HeaderText = "书籍类型";
            this.TypeName.MinimumWidth = 6;
            this.TypeName.Name = "TypeName";
            this.TypeName.ReadOnly = true;
            this.TypeName.Width = 125;
            // 
            // PBdate
            // 
            this.PBdate.DataPropertyName = "PBdate";
            dataGridViewCellStyle1.Format = "D";
            dataGridViewCellStyle1.NullValue = null;
            this.PBdate.DefaultCellStyle = dataGridViewCellStyle1;
            this.PBdate.HeaderText = "添加日期";
            this.PBdate.MinimumWidth = 6;
            this.PBdate.Name = "PBdate";
            this.PBdate.ReadOnly = true;
            this.PBdate.Width = 125;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            dataGridViewCellStyle2.Format = "N2";
            dataGridViewCellStyle2.NullValue = null;
            this.Price.DefaultCellStyle = dataGridViewCellStyle2;
            this.Price.HeaderText = "价格";
            this.Price.MinimumWidth = 6;
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 125;
            // 
            // Num
            // 
            this.Num.DataPropertyName = "Num";
            this.Num.HeaderText = "数量";
            this.Num.MinimumWidth = 6;
            this.Num.Name = "Num";
            this.Num.ReadOnly = true;
            this.Num.Width = 80;
            // 
            // Introduce
            // 
            this.Introduce.DataPropertyName = "Introduce";
            this.Introduce.HeaderText = "书籍简介";
            this.Introduce.MinimumWidth = 6;
            this.Introduce.Name = "Introduce";
            this.Introduce.ReadOnly = true;
            this.Introduce.Width = 125;
            // 
            // BorrowCount
            // 
            this.BorrowCount.DataPropertyName = "BorrowCount";
            this.BorrowCount.HeaderText = "借出数量";
            this.BorrowCount.MinimumWidth = 6;
            this.BorrowCount.Name = "BorrowCount";
            this.BorrowCount.ReadOnly = true;
            this.BorrowCount.Width = 80;
            // 
            // IsDel
            // 
            this.IsDel.DataPropertyName = "IsDel";
            this.IsDel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.IsDel.HeaderText = "是否下架";
            this.IsDel.MinimumWidth = 6;
            this.IsDel.Name = "IsDel";
            this.IsDel.ReadOnly = true;
            this.IsDel.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.IsDel.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.IsDel.Width = 125;
            // 
            // FormBookInform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 582);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormBookInform";
            this.Text = "FormBookInform";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormBookInform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Book_dgv)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Book_dgv;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem add_tsm;
        private System.Windows.Forms.ToolStripMenuItem edit_tsm;
        private System.Windows.Forms.ToolStripMenuItem down_tsm;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox bookname_tbx;
        private System.Windows.Forms.ComboBox type_cbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem up_tsm;
        private System.Windows.Forms.Button start_btn;
        private System.Windows.Forms.CheckBox down_check;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Author;
        private System.Windows.Forms.DataGridViewTextBoxColumn Publisher;
        private System.Windows.Forms.DataGridViewTextBoxColumn TypeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PBdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Num;
        private System.Windows.Forms.DataGridViewTextBoxColumn Introduce;
        private System.Windows.Forms.DataGridViewTextBoxColumn BorrowCount;
        private System.Windows.Forms.DataGridViewCheckBoxColumn IsDel;
    }
}