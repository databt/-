﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Renew_Library_System
{
    public partial class FormUserInformMana : Form
    {
        public FormUserInformMana()
        {
            InitializeComponent();
        }

        private void FormUserInformMana_Load(object sender, EventArgs e)
        {
            bingdgv();
        }

        private void bingdgv()
        {
            string username = UserName_tbx.Text.Trim();
            bool isDel = checkBox1.Checked;
            UserMana_dgv.AutoGenerateColumns = false;
            UserMana_dgv.DataSource = Users.GetListAllJoinUsers().FindAll(
m => m.Name.Contains(username) && m.IsDel == isDel);
        }

        private void Refer_btn_Click(object sender, EventArgs e)
        {
            bingdgv();
        }

        private void UserMana_dgv_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex > -1)
                {
                    UserMana_dgv.ClearSelection();
                    //锁定选中的一行
                    UserMana_dgv.Rows[e.RowIndex].Selected = true;
                    bool isdel = Convert.ToBoolean(UserMana_dgv.SelectedRows[0].Cells["IsDel"].Value);
                    if (isdel)
                    {
                        启用ToolStripMenuItem.Visible = true;
                    }
                    else
                    {
                        停用ToolStripMenuItem.Visible = true;
                    }
                }
            }
        }

        private void UserMana_dgv_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                停用ToolStripMenuItem.Visible = false;
                启用ToolStripMenuItem.Visible = false;
            }
        }

        private void 停用ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("是否停用该账户？", "消息", MessageBoxButtons.YesNo, MessageBoxIcon.Information))
            {
                string Name = UserMana_dgv.SelectedRows[0].Cells["UserName"].Value.ToString();
                int UserID = (int)UserMana_dgv.SelectedRows[0].Cells["UserID"].Value;
                bool IsDel = true;
                Users.DisableorEnable(Name, UserID, IsDel);
                MessageBox.Show("账户已停用","消息",MessageBoxButtons.OK, MessageBoxIcon.Information);
                bingdgv();
            }
        }

        private void 启用ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("是否启用该账户？", "消息", MessageBoxButtons.YesNo, MessageBoxIcon.Information))
            {
                string Name = UserMana_dgv.SelectedRows[0].Cells["UserName"].Value.ToString();
                int UserID = (int)UserMana_dgv.SelectedRows[0].Cells["UserID"].Value;
                bool IsDel = false;
                Users.DisableorEnable(Name, UserID, IsDel);
                MessageBox.Show("账户已启用", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                bingdgv();
            }
        }
    }
}
