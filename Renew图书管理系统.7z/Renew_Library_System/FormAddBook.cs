﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace Renew_Library_System
{
    public partial class FormAddBook : Form
    {
        private Delbingdgv _delbingdgv;
        private Books _book;
        public FormAddBook(Delbingdgv delbingdgv)
        {
            InitializeComponent();
            _delbingdgv = delbingdgv;
        }
        public FormAddBook(Delbingdgv delbingdgv, int id) : this(delbingdgv)
        {
            _book = Books.GetListJoinBook().Find(x => x.Id == id);
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Add_btn_Click(object sender, EventArgs e)
        {
            if (bookName_tbx.Text == string.Empty || author_tbx.Text == string.Empty || price_tbx.Text == string.Empty
|| publisher_tbx.Text == string.Empty || bookType_cbx.Text == string.Empty || addNum_tbx.Text == string.Empty)
            {
                MessageBox.Show("请补全所有信息！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (borrowNum_tbx.Text == string.Empty)
            {
                borrowNum_tbx.Text = "0";
            }
            string name = bookName_tbx.Text.Trim();
            string author = author_tbx.Text.Trim();
            string publicier = publisher_tbx.Text.Trim();
            int typeid = bookType_cbx.SelectedIndex+1;
            int price = Convert.ToInt32(price_tbx.Text);
            int num = Convert.ToInt32(addNum_tbx.Text);
            string introduce = intro_rtb.Text;
            int loanNum = Convert.ToInt32(borrowNum_tbx.Text);
            DateTime dateTime = Time.Value;
            if (_book == null)
            {
                Books books = new Books
                {
                    Name = name,
                    Author = author,
                    Price = price,
                    Publisher = publicier,
                    TypeID = typeid,
                    Num = num,
                    Introduce = introduce,
                    PBdate = dateTime,
                    BorrowCount = loanNum,
                    IsDel = false
                };
                Books.Insert(books);
                MessageBox.Show("添加成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                _book.Name = name;
                _book.Author = author;
                _book.Price = price;
                _book.Publisher = publicier;
                _book.TypeID = typeid;
                _book.Num = num;
                _book.Introduce = introduce;
                _book.PBdate = dateTime;
                _book.BorrowCount = loanNum;
                _book.IsDel = false;
                Books.Update(_book);
                MessageBox.Show("修改成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            _delbingdgv();
            this.Close();
        }

        private void FormAddBook_Load(object sender, EventArgs e)
        {
            List<BookType> bookType = new List<BookType>();
            bookType.AddRange(BookType.ListAll());
            bookType_cbx.DataSource = bookType;
            bookType_cbx.DisplayMember = "typeName";
            bookType_cbx.ValueMember = "IDtype";

            ////添加图书显示空实例，然后没有这个去重复项，修改后有重复的图书类型。
            //List<string> uniqueNames = new List<string>();

            //foreach (var book in _book.TypeName)
            //{
            //    var duplicate = false;
            //    foreach (var existingName in uniqueNames)
            //    {
            //        if (existingName == book.ToString()) // 使用ToString()方法将book转换为字符串进行比较  
            //        {
            //            duplicate = true;
            //            break;
            //        }
            //    }
            //    if (!duplicate)
            //    {
            //        uniqueNames.Add(book.ToString()); // 将book转换为字符串后添加到列表中  
            //    }
            //}

            //// 将uniqueNames设置为数据源    
            //bookType_cbx.DataSource = uniqueNames; // 这里应该是uniqueNames而不是books  
            //bookType_cbx.DisplayMember = "TypeName"; // 指定要显示的属性
            //bookType_cbx.ValueMember = "TypeID";
            if (_book != null)
            {
                bookName_tbx.Text = _book.Name;
                author_tbx.Text = _book.Author;
                publisher_tbx.Text = _book.Publisher;
                bookType_cbx.SelectedValue = _book.TypeID;
                addNum_tbx.Text = _book.Num.ToString();
                borrowNum_tbx.Text = _book.BorrowCount.ToString();
                price_tbx.Text = _book.Price.ToString();
                Time.Value = _book.PBdate;
                intro_rtb.Text = _book.Introduce.ToString();
            }
        }
    }
}
