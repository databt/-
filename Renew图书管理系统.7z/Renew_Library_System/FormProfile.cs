﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormProfile : Form
    {
        private Books _books;
        private Comment _comment;
        private int set;
        public FormProfile(int id)
        {
            InitializeComponent();
            _books = Books.GetListJoinBook().Find(x => x.Id == id);
            set = 1;
        }
        public FormProfile(string Bname)
        {
            InitializeComponent();
            _comment = Comment.GetListAllJoinComment().Find(x => x.Bname == Bname);
            set = 2;
        }

        private void FormProfile_Load(object sender, EventArgs e)
        {
            Profile_rtbx.ReadOnly = true;
            if(set == 1)
            {
                Profile_rtbx.Text = _books.Introduce;
            }
            if(set == 2)
            {
                Profile_rtbx.Text = _comment.Words;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
