﻿namespace Renew_Library_System
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("个人信息管理");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("查看用户租借情况");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("用户信息管理");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("业务管理", new System.Windows.Forms.TreeNode[] {
            treeNode2,
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("图书情况");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("图书评价管理");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("反馈管理");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("用户反馈", new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode7});
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.button1 = new System.Windows.Forms.Button();
            this.Menu_treeView = new System.Windows.Forms.TreeView();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.Azure;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button1);
            this.splitContainer1.Panel1.Controls.Add(this.Menu_treeView);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.Azure;
            this.splitContainer1.Size = new System.Drawing.Size(1137, 683);
            this.splitContainer1.SplitterDistance = 239;
            this.splitContainer1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(12, 560);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 57);
            this.button1.TabIndex = 2;
            this.button1.Text = "退出登录";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Menu_treeView
            // 
            this.Menu_treeView.BackColor = System.Drawing.Color.Azure;
            this.Menu_treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Menu_treeView.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Menu_treeView.FullRowSelect = true;
            this.Menu_treeView.ItemHeight = 55;
            this.Menu_treeView.Location = new System.Drawing.Point(0, 0);
            this.Menu_treeView.Name = "Menu_treeView";
            treeNode1.Name = "Personal";
            treeNode1.Tag = "FormPersonal";
            treeNode1.Text = "个人信息管理";
            treeNode2.Name = "节点6";
            treeNode2.Tag = "FormLookUser";
            treeNode2.Text = "查看用户租借情况";
            treeNode3.Name = "节点7";
            treeNode3.Tag = "FormUserInformMana";
            treeNode3.Text = "用户信息管理";
            treeNode4.Checked = true;
            treeNode4.Name = "节点5";
            treeNode4.Tag = "FormNone";
            treeNode4.Text = "业务管理";
            treeNode5.Name = "BookInform";
            treeNode5.Tag = "FormBookInform";
            treeNode5.Text = "图书情况";
            treeNode6.Name = "节点14";
            treeNode6.Tag = "FormEvaluateMana";
            treeNode6.Text = "图书评价管理";
            treeNode7.Name = "节点15";
            treeNode7.Tag = "FormNewsMana";
            treeNode7.Text = "反馈管理";
            treeNode8.Name = "节点13";
            treeNode8.Tag = "FormNone";
            treeNode8.Text = "用户反馈";
            this.Menu_treeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode4,
            treeNode5,
            treeNode8});
            this.Menu_treeView.ShowLines = false;
            this.Menu_treeView.Size = new System.Drawing.Size(239, 683);
            this.Menu_treeView.TabIndex = 0;
            this.Menu_treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.Menu_treeView_AfterSelect);
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 683);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.Name = "FormAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormAdmin";
            this.Load += new System.EventHandler(this.FormAdmin_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView Menu_treeView;
        private System.Windows.Forms.Button button1;
    }
}