﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Renew_Library_System
{
    //用户、管理共用
    public partial class FormAlterPw : Form
    {
        private Users _users;
        private Admins _admins;
        private int _id;
        private string _UorA;
        public FormAlterPw( int id, string UorA)
        {
            InitializeComponent();
            _id = id;
            _UorA = UorA;
        }

        private void yanzheng_btn_Click(object sender, EventArgs e)
        {
            string acc = textBox2.Text.Trim();
            if (_UorA == "U")
            {
                if (Users.Select(_id, acc) == true)
                {
                    MessageBox.Show("验证成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ps_tbx.Visible = true;
                    reps_tbx.Visible = true;
                    _users = Users.ListAll().Find(x => x.UserID == _id);
                }
                else
                {
                    MessageBox.Show("验证失败", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                if (Admins.Select(_id, acc) == true)
                {
                    MessageBox.Show("验证成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ps_tbx.Visible = true;
                    reps_tbx.Visible = true;
                    _admins = Admins.ListAll().Find(x => x.AdminID == _id);
                }
                else
                {
                    MessageBox.Show("验证失败", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void ps_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Z0-9]");
            ps_tbx.Text = regex.Replace(ps_tbx.Text, "");
        }

        private void reps_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Z0-9]");
            ps_tbx.Text = regex.Replace(ps_tbx.Text, "");
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void enter_btn_Click(object sender, EventArgs e)
        {
            if(ps_tbx.Text == reps_tbx.Text) { 
                MessageBox.Show("修改成功","消息",MessageBoxButtons.OK, MessageBoxIcon.Information);
                if(_UorA == "U")
                {
                    _admins.Adminpassword = ps_tbx.Text;
                }
                else{
                    _users.UserPassword = ps_tbx.Text;
                }
            }
            else
            {
                MessageBox.Show("两次密码不一致", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
