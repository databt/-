﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    //忘记密码
    public partial class FormForgetPs : Form
    {
        private Users _users;
        public FormForgetPs()
        {
            InitializeComponent();
        }

        private void yanzheng_btn_Click(object sender, EventArgs e)
        {
            string na = textBox1.Text.Trim();
            int acc = Convert.ToInt32(textBox2.Text.Trim());
            if(Users.Select(na, acc) == true)
            {
                MessageBox.Show("验证成功", "消息",MessageBoxButtons.OK,MessageBoxIcon.Information);
                ps_tbx.Visible = true;
                reps_tbx.Visible = true;
                _users = Users.ListAll().Find(x => x.UserID == acc);
            }
            else 
            {
                MessageBox.Show("验证失败", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void enter_btn_Click(object sender, EventArgs e)
        {
            
            if (ps_tbx.Text == "" || reps_tbx.Text == "")
            {
                MessageBox.Show("请补全所有信息！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (ps_tbx.Text != reps_tbx.Text)
            {
                MessageBox.Show("两次密码输入不一致！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string ps = ps_tbx.Text.Trim(); 
            _users.UserPassword = ps;
            Users.Update(_users);
            MessageBox.Show("修改成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void ps_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Z0-9]");
            ps_tbx.Text = regex.Replace(ps_tbx.Text, "");
        }

        private void reps_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Z0-9]");
            reps_tbx.Text = regex.Replace(reps_tbx.Text, "");
        }
    }
}
