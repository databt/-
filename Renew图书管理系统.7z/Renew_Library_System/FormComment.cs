﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormComment : Form
    {
        private string _uname;
        public FormComment(string Uname)
        {
            InitializeComponent();
            _uname = Uname;
        }

        private void FormComment_Load(object sender, EventArgs e)
        {
            bingcbx();
            bingdgv();
        }
        private void bingdgv()
        {
            string bookname = Bname_tbx.Text.Trim();
            int typeID = (int)type_cbx.SelectedValue;
            Comments_dgv.AutoGenerateColumns = false;
            if (typeID == 0)
            {
                Comments_dgv.DataSource = Comment.GetListAllJoinComment().FindAll(
m => m.Bname.Contains(bookname));
            }
            else
            {
                Comments_dgv.DataSource = Comment.GetListAllJoinComment().FindAll(
m => m.Bname.Contains(bookname) && m.typeID == typeID);
            }
        }

        private void bingcbx()
        {
            List<BookType> booktype = new List<BookType>();
            booktype.AddRange(BookType.ListAll());
            booktype.Insert(0, new BookType
            {
                IDtype = 0,
                TypeName = "-查询所有-"
            });
            type_cbx.DataSource = booktype;
            type_cbx.DisplayMember = "typeName";
            type_cbx.ValueMember = "IDtype";
        }

        private void Refer_btn_Click(object sender, EventArgs e)
        {
            bingdgv();
        }

        private void mycomment_btn_Click(object sender, EventArgs e)
        {
            FormMyComment formMyComment = new FormMyComment(_uname);
            formMyComment.ShowDialog();
            bingdgv();
        }

        private void Comments_dgv_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex > -1)
                {
                    Comments_dgv.ClearSelection();
                    //锁定选中的一行
                    Comments_dgv.Rows[e.RowIndex].Selected = true;
                    查看评论ToolStripMenuItem.Visible = true;
                }
            }
        }

        private void Comments_dgv_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                查看评论ToolStripMenuItem.Visible = false;
            }
        }

        private void 查看评论ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string Bname = Comments_dgv.SelectedRows[0].Cells["Bname"].Value.ToString();
            FormProfile formProfile = new FormProfile(Bname);
            formProfile.ShowDialog();
        }
    }
}
