﻿namespace Renew_Library_System
{
    partial class FormAddBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.bookName_tbx = new System.Windows.Forms.TextBox();
            this.borrowNum_tbx = new System.Windows.Forms.TextBox();
            this.addNum_tbx = new System.Windows.Forms.TextBox();
            this.publisher_tbx = new System.Windows.Forms.TextBox();
            this.author_tbx = new System.Windows.Forms.TextBox();
            this.intro_rtb = new System.Windows.Forms.RichTextBox();
            this.Time = new System.Windows.Forms.DateTimePicker();
            this.Add_btn = new System.Windows.Forms.Button();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.price_tbx = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bookType_cbx = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(110, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "书名";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label.Location = new System.Drawing.Point(54, 179);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(129, 37);
            this.label.TabIndex = 1;
            this.label.Text = "添加数量";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(433, 259);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 37);
            this.label3.TabIndex = 2;
            this.label3.Text = "录入日期";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(92, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 37);
            this.label4.TabIndex = 3;
            this.label4.Text = "简介";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(433, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 37);
            this.label5.TabIndex = 4;
            this.label5.Text = "图书类型";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(82, 102);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 37);
            this.label6.TabIndex = 5;
            this.label6.Text = "出版社";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(489, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 37);
            this.label7.TabIndex = 6;
            this.label7.Text = "作者";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(433, 180);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(129, 37);
            this.label8.TabIndex = 7;
            this.label8.Text = "借出数量";
            // 
            // bookName_tbx
            // 
            this.bookName_tbx.Location = new System.Drawing.Point(196, 22);
            this.bookName_tbx.Name = "bookName_tbx";
            this.bookName_tbx.Size = new System.Drawing.Size(199, 43);
            this.bookName_tbx.TabIndex = 9;
            // 
            // borrowNum_tbx
            // 
            this.borrowNum_tbx.Location = new System.Drawing.Point(567, 180);
            this.borrowNum_tbx.Name = "borrowNum_tbx";
            this.borrowNum_tbx.Size = new System.Drawing.Size(199, 43);
            this.borrowNum_tbx.TabIndex = 15;
            // 
            // addNum_tbx
            // 
            this.addNum_tbx.Location = new System.Drawing.Point(196, 180);
            this.addNum_tbx.Name = "addNum_tbx";
            this.addNum_tbx.Size = new System.Drawing.Size(199, 43);
            this.addNum_tbx.TabIndex = 16;
            // 
            // publisher_tbx
            // 
            this.publisher_tbx.Location = new System.Drawing.Point(196, 103);
            this.publisher_tbx.Name = "publisher_tbx";
            this.publisher_tbx.Size = new System.Drawing.Size(199, 43);
            this.publisher_tbx.TabIndex = 17;
            // 
            // author_tbx
            // 
            this.author_tbx.Location = new System.Drawing.Point(567, 19);
            this.author_tbx.Name = "author_tbx";
            this.author_tbx.Size = new System.Drawing.Size(199, 43);
            this.author_tbx.TabIndex = 19;
            // 
            // intro_rtb
            // 
            this.intro_rtb.Location = new System.Drawing.Point(178, 353);
            this.intro_rtb.Name = "intro_rtb";
            this.intro_rtb.Size = new System.Drawing.Size(570, 179);
            this.intro_rtb.TabIndex = 20;
            this.intro_rtb.Text = "";
            // 
            // Time
            // 
            this.Time.Location = new System.Drawing.Point(575, 259);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(281, 43);
            this.Time.TabIndex = 21;
            this.Time.Value = new System.DateTime(2024, 1, 11, 0, 0, 0, 0);
            // 
            // Add_btn
            // 
            this.Add_btn.Location = new System.Drawing.Point(179, 585);
            this.Add_btn.Name = "Add_btn";
            this.Add_btn.Size = new System.Drawing.Size(150, 73);
            this.Add_btn.TabIndex = 22;
            this.Add_btn.Text = "确定";
            this.Add_btn.UseVisualStyleBackColor = true;
            this.Add_btn.Click += new System.EventHandler(this.Add_btn_Click);
            // 
            // cancel_btn
            // 
            this.cancel_btn.Location = new System.Drawing.Point(515, 585);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(150, 73);
            this.cancel_btn.TabIndex = 23;
            this.cancel_btn.Text = "取消";
            this.cancel_btn.UseVisualStyleBackColor = true;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // price_tbx
            // 
            this.price_tbx.Location = new System.Drawing.Point(196, 256);
            this.price_tbx.Name = "price_tbx";
            this.price_tbx.Size = new System.Drawing.Size(199, 43);
            this.price_tbx.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(110, 259);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(73, 37);
            this.label2.TabIndex = 24;
            this.label2.Text = "价格";
            // 
            // bookType_cbx
            // 
            this.bookType_cbx.FormattingEnabled = true;
            this.bookType_cbx.Location = new System.Drawing.Point(567, 99);
            this.bookType_cbx.Name = "bookType_cbx";
            this.bookType_cbx.Size = new System.Drawing.Size(199, 44);
            this.bookType_cbx.TabIndex = 26;
            // 
            // FormAddBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(874, 723);
            this.Controls.Add(this.bookType_cbx);
            this.Controls.Add(this.price_tbx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cancel_btn);
            this.Controls.Add(this.Add_btn);
            this.Controls.Add(this.Time);
            this.Controls.Add(this.intro_rtb);
            this.Controls.Add(this.author_tbx);
            this.Controls.Add(this.publisher_tbx);
            this.Controls.Add(this.addNum_tbx);
            this.Controls.Add(this.borrowNum_tbx);
            this.Controls.Add(this.bookName_tbx);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("微软雅黑", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(7);
            this.Name = "FormAddBook";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "编辑图书";
            this.Load += new System.EventHandler(this.FormAddBook_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox bookName_tbx;
        private System.Windows.Forms.TextBox borrowNum_tbx;
        private System.Windows.Forms.TextBox addNum_tbx;
        private System.Windows.Forms.TextBox publisher_tbx;
        private System.Windows.Forms.TextBox author_tbx;
        private System.Windows.Forms.RichTextBox intro_rtb;
        private System.Windows.Forms.DateTimePicker Time;
        private System.Windows.Forms.Button Add_btn;
        private System.Windows.Forms.Button cancel_btn;
        private System.Windows.Forms.TextBox price_tbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox bookType_cbx;
    }
}