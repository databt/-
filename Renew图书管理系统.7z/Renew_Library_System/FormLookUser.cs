﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormLookUser : Form
    {
        private Delbingdgv _delbingdgv;

        public FormLookUser()
        {
            InitializeComponent();
        }

        private void FormLookUser_Load(object sender, EventArgs e) 
        {
            bingcbx();
            bingdgv();
            _delbingdgv = bingdgv;
        }

        private void bingcbx()
        {
            List<BookType> booktype = new List<BookType>();
            booktype.AddRange(BookType.ListAll());
            booktype.Insert(0, new BookType
            {
                IDtype = 0,
                TypeName = "-查询所有-"
            });
            type_cbx.DataSource = booktype;
            type_cbx.DisplayMember = "typeName";
            type_cbx.ValueMember = "IDtype";
        }

        private void bingdgv()
        {
            string username = UserName_tbx.Text.Trim();
            string bookname = BookName_tbx.Text.Trim();
            int userid = (UserID_tbx.Text.Trim()!=string.Empty)? Convert.ToInt32(UserID_tbx.Text.Trim()):0;
            int typeID = (int)type_cbx.SelectedValue;
            bool isDel = checkBox1.Checked;
            UserMana_dgv.AutoGenerateColumns = false;
            if (typeID == 0)
            {
                UserMana_dgv.DataSource = LookUser.GetListAllJoinLookUser().FindAll(
m => m.Name.Contains(username) && m.BookName.Contains(bookname) 
&& m.UserID.ToString().Contains(userid.ToString()) && m.IsDel == isDel);
            } 
            else
            {
                UserMana_dgv.DataSource = LookUser.GetListAllJoinLookUser().FindAll(
m => m.Name.Contains(username) && m.BookName.Contains(bookname) 
&& m.UserID.ToString().Contains(userid.ToString()) &&
m.IDtype == typeID && m.IsDel == isDel);
            }
        }

        private void Refer_btn_Click(object sender, EventArgs e)
        {
            bingdgv();
        }
    }
}
