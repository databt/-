﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Models;

namespace Renew_Library_System
{
    public delegate void Delbingdgv();
    public partial class FormBookInform : Form
    {
        private Delbingdgv _delbingdgv;
        public FormBookInform()
        {
            InitializeComponent();
        }

        private void FormBookInform_Load(object sender, EventArgs e)
        {
            bingcbx();
            bingdgv();
            _delbingdgv = bingdgv;
        }

        private void bingcbx()
        {
            //书籍类型的查询
            List<BookType> booktype = new List<BookType>();
            booktype.AddRange(BookType.ListAll());
            booktype.Insert(0, new BookType
            {
                IDtype = 0,
                TypeName = "-查询所有-"
            });
            type_cbx.DataSource = booktype;
            type_cbx.DisplayMember = "typeName";
            type_cbx.ValueMember = "IDtype";
        }

        private void bingdgv()
        {
            //筛选项：书名、书籍类型
            string bookname = bookname_tbx.Text.Trim();
            int typeID = (int)type_cbx.SelectedValue;
            bool isDel = down_check.Checked;
            Book_dgv.AutoGenerateColumns = false;
            if (typeID == 0)
            {
                Book_dgv.DataSource = Books.GetListJoinBook().FindAll(
m => m.Name.Contains(bookname) && m.IsDel == isDel);
            }
            else
            {
                Book_dgv.DataSource = Books.GetListJoinBook().FindAll(
m => m.Name.Contains(bookname) && m.TypeID == typeID && m.IsDel == isDel);
            }
        }

        private void Book_dgv_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                add_tsm.Visible = true;
                edit_tsm.Visible = false;
                down_tsm.Visible = false;
                up_tsm.Visible = false;
            }
        }

        private void Book_dgv_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex > -1)
                {
                    Book_dgv.ClearSelection();
                    Book_dgv.Rows[e.RowIndex].Selected = true;
                    add_tsm.Visible = true;
                    edit_tsm.Visible = true;
                    bool isDel = (bool)Book_dgv.SelectedRows[0].Cells["IsDel"].Value;
                    if (isDel)
                    {
                        up_tsm.Visible = true;
                    }
                    else
                    {
                        down_tsm.Visible = true;
                    }
                }
            }
        }

        private void add_tsm_Click(object sender, EventArgs e)
        {
            FormAddBook formAddBook = new FormAddBook(_delbingdgv);
            formAddBook.ShowDialog();
            bingdgv();
        }

        private void edit_tsm_Click(object sender, EventArgs e)
        {
            int id = (int)Book_dgv.SelectedRows[0].Cells["ID"].Value;
            FormAddBook formAddBook = new FormAddBook(_delbingdgv, id);
            formAddBook.ShowDialog();
            bingdgv();
        }

        private void downOrup()
        {
            bool isdel = (bool)Book_dgv.SelectedRows[0].Cells["IsDel"].Value;
            int id = (int)Book_dgv.SelectedRows[0].Cells["ID"].Value;
            Books books = new Books();
            books = Books.GetListJoinBook().Find(m => m.Id == id);
            if (isdel)
            {
                books.IsDel = false;
                MessageBox.Show("图书已上架", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                books.IsDel = true;
                MessageBox.Show("图书已下架", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            Books.Update(books);

            bingdgv();
        }

        private void down_tsm_Click(object sender, EventArgs e)
        {
            downOrup();
        }

        private void up_tsm_Click(object sender, EventArgs e)
        {
            downOrup();
        }

        private void start_btn_Click(object sender, EventArgs e)
        {
            bingdgv();
        }
    }
}
