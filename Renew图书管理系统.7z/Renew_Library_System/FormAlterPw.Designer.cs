﻿namespace Renew_Library_System
{
    partial class FormAlterPw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.enter_btn = new System.Windows.Forms.Button();
            this.reps_tbx = new System.Windows.Forms.TextBox();
            this.ps_tbx = new System.Windows.Forms.TextBox();
            this.yanzheng_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(210, 96);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(260, 40);
            this.textBox2.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 99);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(140, 33);
            this.label5.TabIndex = 21;
            this.label5.Text = "原密码验证";
            // 
            // cancel_btn
            // 
            this.cancel_btn.Location = new System.Drawing.Point(344, 399);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(139, 53);
            this.cancel_btn.TabIndex = 20;
            this.cancel_btn.Text = "取消";
            this.cancel_btn.UseVisualStyleBackColor = true;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // enter_btn
            // 
            this.enter_btn.Location = new System.Drawing.Point(115, 399);
            this.enter_btn.Name = "enter_btn";
            this.enter_btn.Size = new System.Drawing.Size(139, 53);
            this.enter_btn.TabIndex = 19;
            this.enter_btn.Text = "确认";
            this.enter_btn.UseVisualStyleBackColor = true;
            this.enter_btn.Click += new System.EventHandler(this.enter_btn_Click);
            // 
            // reps_tbx
            // 
            this.reps_tbx.Location = new System.Drawing.Point(210, 331);
            this.reps_tbx.Name = "reps_tbx";
            this.reps_tbx.Size = new System.Drawing.Size(260, 40);
            this.reps_tbx.TabIndex = 18;
            this.reps_tbx.Visible = false;
            this.reps_tbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.reps_tbx_KeyPress);
            // 
            // ps_tbx
            // 
            this.ps_tbx.Location = new System.Drawing.Point(210, 265);
            this.ps_tbx.Name = "ps_tbx";
            this.ps_tbx.Size = new System.Drawing.Size(260, 40);
            this.ps_tbx.TabIndex = 17;
            this.ps_tbx.Visible = false;
            this.ps_tbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ps_tbx_KeyPress);
            // 
            // yanzheng_btn
            // 
            this.yanzheng_btn.Location = new System.Drawing.Point(238, 164);
            this.yanzheng_btn.Name = "yanzheng_btn";
            this.yanzheng_btn.Size = new System.Drawing.Size(139, 53);
            this.yanzheng_btn.TabIndex = 15;
            this.yanzheng_btn.Text = "验证";
            this.yanzheng_btn.UseVisualStyleBackColor = true;
            this.yanzheng_btn.Click += new System.EventHandler(this.yanzheng_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 331);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 33);
            this.label3.TabIndex = 14;
            this.label3.Text = "确认密码";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(126, 272);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 33);
            this.label2.TabIndex = 13;
            this.label2.Text = "密码";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(12, 9);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(290, 33);
            this.label4.TabIndex = 23;
            this.label4.Text = "注：验证后方可修改密码";
            // 
            // FormAlterPw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 33F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(606, 543);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cancel_btn);
            this.Controls.Add(this.enter_btn);
            this.Controls.Add(this.reps_tbx);
            this.Controls.Add(this.ps_tbx);
            this.Controls.Add(this.yanzheng_btn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "FormAlterPw";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormAlterPw";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button cancel_btn;
        private System.Windows.Forms.Button enter_btn;
        private System.Windows.Forms.TextBox reps_tbx;
        private System.Windows.Forms.TextBox ps_tbx;
        private System.Windows.Forms.Button yanzheng_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
    }
}