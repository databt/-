﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ulitity;
using static System.Net.Mime.MediaTypeNames;

namespace Renew_Library_System
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("是否退出系统？", "消息", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //退出系统要检查账号和密码是不是空的，不是没法退出
            if (Account_tbx.Text == string.Empty && Password_tbx.Text == string.Empty)
            {
                if (result == DialogResult.Yes)
                {
                    System.Windows.Forms.Application.Exit();
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (result == DialogResult.Yes)
                {
                    Account_tbx.Text = string.Empty; Password_tbx.Text = string.Empty;
                    System.Windows.Forms.Application.Exit();
                }
                else
                {
                    return;
                }
            }
        }

        private void Login_btn_Click(object sender, EventArgs e)
        {
            string UorA;
            if (Account_tbx.Text == string.Empty || Password_tbx.Text == string.Empty)
            {
                MessageBox.Show("请输入账号或密码", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (User_radio.Checked == true)
            {
                UorA = "U";
                UorALogin(UorA);
            }
            if (Admin_radio.Checked == true)
            {
                UorA = "A";
                UorALogin(UorA);
            }
        }
        //管理员/用户登录
        private void UorALogin(string UorA)
        {
            int i = 0;
            int id = int.Parse(Account_tbx.Text);
            string password = Password_tbx.Text;
            if (UorA == "A")
            {
                DataTable dataTable = SqlHelper.ExecuteTable("select * from 管理员库");
                foreach (DataRow row in dataTable.Rows)
                {
                    string name = row["Name"].ToString();
                    int adminid = (int)row["AdminID"];
                    string adminpassword = row["Adminpassword"].ToString();
                    if (id == adminid && password == adminpassword)
                    {
                        i = 1;
                        MessageBox.Show("登录成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        FormAdmin formAdmin = new FormAdmin(name,adminid,UorA);
                        this.Visible = false;
                        formAdmin.ShowDialog();
                        this.Visible = true;
                        break;
                    }
                }
                if (i == 0)
                {
                    MessageBox.Show("登录失败！请查看账号或密码是否正确", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            if (UorA == "U")
            {
                DataTable dataTable = SqlHelper.ExecuteTable("select UserID , UserPassword,Name from 用户库");
                foreach (DataRow row in dataTable.Rows)
                {
                    int userid = (int)row["UserID"];
                    string userpassword = row["UserPassword"].ToString();
                    string name = row["Name"].ToString();
                    if (id == userid && password == userpassword)
                    {
                        i = 1;
                        MessageBox.Show("登录成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        FormUser formUser = new FormUser(name,userid,UorA);
                        this.Visible = false;
                        formUser.ShowDialog();
                        this.Visible = true;
                        break;
                    }
                }
                if (i == 0)
                {
                    MessageBox.Show("登录失败！请查看账号或密码是否正确", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
        }
        //用户注册
        private void Enroll_btn_Click(object sender, EventArgs e)
        {
            FormEnroll formEnroll = new FormEnroll();
            formEnroll.ShowDialog();
        }
        //忘记密码
        private void ForgetPs_btn_Click(object sender, EventArgs e)
        {
            FormForgetPs formForgetPs = new FormForgetPs();
            formForgetPs.ShowDialog();
        }

        private void Admin_radio_CheckedChanged(object sender, EventArgs e)
        {
            if (Admin_radio.Checked == true)
            {
                ForgetPs_btn.Visible = false;
                Enroll_btn.Visible = false;
            }
            else
            {
                ForgetPs_btn.Visible = true;
                Enroll_btn.Visible = true;
            }
        }
    }
}
