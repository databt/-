﻿namespace Renew_Library_System
{
    partial class FormLogin
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.User_radio = new System.Windows.Forms.RadioButton();
            this.Admin_radio = new System.Windows.Forms.RadioButton();
            this.exit_btn = new System.Windows.Forms.Button();
            this.Enroll_btn = new System.Windows.Forms.Button();
            this.Account_tbx = new System.Windows.Forms.TextBox();
            this.Password_tbx = new System.Windows.Forms.TextBox();
            this.ForgetPs_btn = new System.Windows.Forms.Button();
            this.Login_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(146, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(348, 57);
            this.label1.TabIndex = 0;
            this.label1.Text = "图 书 管 理 系 统";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SkyBlue;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(117, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 33);
            this.label2.TabIndex = 1;
            this.label2.Text = "账号";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.SkyBlue;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(117, 254);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 33);
            this.label3.TabIndex = 2;
            this.label3.Text = "密码";
            // 
            // User_radio
            // 
            this.User_radio.AutoSize = true;
            this.User_radio.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.User_radio.Location = new System.Drawing.Point(170, 337);
            this.User_radio.Name = "User_radio";
            this.User_radio.Size = new System.Drawing.Size(86, 37);
            this.User_radio.TabIndex = 3;
            this.User_radio.TabStop = true;
            this.User_radio.Text = "用户";
            this.User_radio.UseVisualStyleBackColor = true;
            // 
            // Admin_radio
            // 
            this.Admin_radio.AutoSize = true;
            this.Admin_radio.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Admin_radio.Location = new System.Drawing.Point(330, 337);
            this.Admin_radio.Name = "Admin_radio";
            this.Admin_radio.Size = new System.Drawing.Size(111, 37);
            this.Admin_radio.TabIndex = 4;
            this.Admin_radio.TabStop = true;
            this.Admin_radio.Text = "管理员";
            this.Admin_radio.UseVisualStyleBackColor = true;
            this.Admin_radio.CheckedChanged += new System.EventHandler(this.Admin_radio_CheckedChanged);
            // 
            // exit_btn
            // 
            this.exit_btn.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.exit_btn.Location = new System.Drawing.Point(371, 405);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(85, 42);
            this.exit_btn.TabIndex = 5;
            this.exit_btn.Text = "退出";
            this.exit_btn.UseVisualStyleBackColor = true;
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            // 
            // Enroll_btn
            // 
            this.Enroll_btn.BackColor = System.Drawing.Color.SkyBlue;
            this.Enroll_btn.FlatAppearance.BorderSize = 0;
            this.Enroll_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Enroll_btn.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Enroll_btn.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.Enroll_btn.Location = new System.Drawing.Point(326, 297);
            this.Enroll_btn.Name = "Enroll_btn";
            this.Enroll_btn.Size = new System.Drawing.Size(96, 34);
            this.Enroll_btn.TabIndex = 7;
            this.Enroll_btn.Text = "用户注册";
            this.Enroll_btn.UseVisualStyleBackColor = false;
            this.Enroll_btn.Click += new System.EventHandler(this.Enroll_btn_Click);
            // 
            // Account_tbx
            // 
            this.Account_tbx.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Account_tbx.Location = new System.Drawing.Point(201, 174);
            this.Account_tbx.Name = "Account_tbx";
            this.Account_tbx.Size = new System.Drawing.Size(221, 40);
            this.Account_tbx.TabIndex = 9;
            // 
            // Password_tbx
            // 
            this.Password_tbx.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Password_tbx.Location = new System.Drawing.Point(201, 251);
            this.Password_tbx.Name = "Password_tbx";
            this.Password_tbx.PasswordChar = '*';
            this.Password_tbx.Size = new System.Drawing.Size(221, 40);
            this.Password_tbx.TabIndex = 10;
            // 
            // ForgetPs_btn
            // 
            this.ForgetPs_btn.BackColor = System.Drawing.Color.SkyBlue;
            this.ForgetPs_btn.FlatAppearance.BorderSize = 0;
            this.ForgetPs_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ForgetPs_btn.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ForgetPs_btn.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.ForgetPs_btn.Location = new System.Drawing.Point(201, 297);
            this.ForgetPs_btn.Name = "ForgetPs_btn";
            this.ForgetPs_btn.Size = new System.Drawing.Size(96, 34);
            this.ForgetPs_btn.TabIndex = 11;
            this.ForgetPs_btn.Text = "忘记密码";
            this.ForgetPs_btn.UseVisualStyleBackColor = false;
            this.ForgetPs_btn.Click += new System.EventHandler(this.ForgetPs_btn_Click);
            // 
            // Login_btn
            // 
            this.Login_btn.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Login_btn.Location = new System.Drawing.Point(144, 405);
            this.Login_btn.Name = "Login_btn";
            this.Login_btn.Size = new System.Drawing.Size(85, 42);
            this.Login_btn.TabIndex = 8;
            this.Login_btn.Text = "登录";
            this.Login_btn.UseVisualStyleBackColor = true;
            this.Login_btn.Click += new System.EventHandler(this.Login_btn_Click);
            // 
            // FormLogin
            // 
            this.AcceptButton = this.Login_btn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(607, 498);
            this.Controls.Add(this.ForgetPs_btn);
            this.Controls.Add(this.Password_tbx);
            this.Controls.Add(this.Account_tbx);
            this.Controls.Add(this.Login_btn);
            this.Controls.Add(this.Enroll_btn);
            this.Controls.Add(this.exit_btn);
            this.Controls.Add(this.Admin_radio);
            this.Controls.Add(this.User_radio);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "图书管理系统登录";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton User_radio;
        private System.Windows.Forms.RadioButton Admin_radio;
        private System.Windows.Forms.Button exit_btn;
        private System.Windows.Forms.Button Enroll_btn;
        private System.Windows.Forms.TextBox Account_tbx;
        private System.Windows.Forms.TextBox Password_tbx;
        private System.Windows.Forms.Button ForgetPs_btn;
        private System.Windows.Forms.Button Login_btn;
    }
}

