﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormBorrow : Form
    {
        private string _name;
        private int _id;
        private Books _books;
        public FormBorrow(string name, int id)
        {
            InitializeComponent();
            _name = name;
            _id = id;
        }

        private void FormBorrow_Load(object sender, EventArgs e)
        {
            bingcbx();
            bingdgv();
        }
        private void bingdgv()
        {
            string bookname = BookName_tbx.Text.Trim();
            int typeID = (int)type_cbx.SelectedValue;
            bool isDel = false;
            UBook_dgv.AutoGenerateColumns = false;
            if (typeID == 0)
            {
                UBook_dgv.DataSource = Books.GetListJoinBook().FindAll(
m => m.Name.Contains(bookname) && m.IsDel == isDel);
            }
            else
            {
                UBook_dgv.DataSource = Books.GetListJoinBook().FindAll(
m => m.Name.Contains(bookname) && m.TypeID == typeID && m.IsDel == isDel);
            }
        }

        private void bingcbx()
        {
            List<BookType> booktype = new List<BookType>();
            booktype.AddRange(BookType.ListAll());
            booktype.Insert(0, new BookType
            {
                IDtype = 0,
                TypeName = "-查询所有-"
            });
            type_cbx.DataSource = booktype;
            type_cbx.DisplayMember = "typeName";
            type_cbx.ValueMember = "IDtype";
        }

        private void Refer_btn_Click(object sender, EventArgs e)
        {
            bingdgv();
        }

        private void Borrow_btn_Click(object sender, EventArgs e)
        {
            if (UBook_dgv.SelectedRows.Count > 0)
            {
                string bookname = UBook_dgv.SelectedRows[0].Cells[1].Value.ToString();
                int Id = (int)UBook_dgv.SelectedRows[0].Cells[0].Value;
                string type = UBook_dgv.SelectedRows[0].Cells[4].Value.ToString();
                _books = Books.GetListJoinBook().Find(m => m.Id == Id);
                if (Books.SelectBook(bookname))
                {
                    MessageBox.Show("此书库存不足，不能租借", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    if (DialogResult.Yes == MessageBox.Show("是否租借？", "消息", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                    {
                        if (BRNews.Select(_id, bookname))
                        {
                            MessageBox.Show($"已租借《{bookname}》，不能再借", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            BRNews bRNews = new BRNews
                            {
                                UserID = _id,
                                BookName = bookname,
                                TypeID = BookType.Select(type),
                                NewTime = DateTime.Today,
                                Num = 1,
                                IsDel = false
                            };
                            BRNews.Insert(bRNews);
                            _books.Num -= 1;
                            _books.BorrowCount += 1;
                            Books.Update(_books);
                            MessageBox.Show($"租借《{bookname}》成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            bingdgv();
                        }
                    }
                    else
                    {
                        return;
                    }
                }
            }
            else
            {
                MessageBox.Show("请选择需要租借的图书", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void Return_btn_Click(object sender, EventArgs e)
        {
            if (BRNews.Select(_id))
            {
                FormReturnBook formReturnBook = new FormReturnBook(_id);
                formReturnBook.ShowDialog();
                bingdgv();
            }
            else 
            {
                MessageBox.Show("暂无需要归还的图书", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void 查看简介ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int id = (int)UBook_dgv.SelectedRows[0].Cells["ID"].Value;
            FormProfile profile = new FormProfile(id);
            profile.ShowDialog();
        }

        private void UBook_dgv_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right)
            {
                if(e.RowIndex > -1)
                {
                    UBook_dgv.ClearSelection();
                    //锁定选中的一行
                    UBook_dgv.Rows[e.RowIndex].Selected = true;
                    查看简介ToolStripMenuItem.Visible = true;
                }
            }
        }

        private void UBook_dgv_MouseDown(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right)
            {
                查看简介ToolStripMenuItem.Visible = false;
            }
        }

        private void PubComment_btn_Click(object sender, EventArgs e)
        {
            string name = UBook_dgv.SelectedRows[0].Cells["BookName"].Value.ToString();
            FormPubComment formPubComment = new FormPubComment(name,_name,_id); 
            formPubComment.ShowDialog();
        }
    }
}
