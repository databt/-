﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormPersonal : Form
    {
        private Users _users;
        private Admins _admins;
        private string _UorA;
        private string _name;
        private int _id;
        public FormPersonal(string name,int id,string UorA)
        {
            InitializeComponent();
            _users = Users.ListAll().Find(x => x.UserID == id);
            _admins = Admins.ListAll().Find(x => x.AdminID == id);
            _name = name;
            _id = id;
            _UorA = UorA;
        }

        private void FormPersonal_Load(object sender, EventArgs e)
        {
            if (_UorA == "A")
            {
                this.label1.Text = $"管理员：{_name}\n\n账号：{_id}";
            }
            if (_UorA == "U")
            {
                buttonAddadmin.Visible = false;
                this.label1.Text = $"用户：{_name}\n\n账号：{_id}\n\n电话号码：{_users.Tel}\n\n" +
                    $"身份证号：{_users.IDCard}\n\n性别：{_users.Sex}";
            }
            
        }

        private void buttonModify_Click(object sender, EventArgs e)
        {
            FormAlterPw formAlterPw = new FormAlterPw(_id, _UorA);
            formAlterPw.ShowDialog();
        }

        private void buttonRemoval_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("是否注销账号？", "注意",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                if (_UorA == "A")
                {
                    Admins.Delete(_admins);
                    MessageBox.Show("注销成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                if (_UorA == "U")
                {
                    Users.Delete(_users);
                    MessageBox.Show("注销成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
        }

        private void buttonAddadmin_Click(object sender, EventArgs e)
        {

        }
    }
}
