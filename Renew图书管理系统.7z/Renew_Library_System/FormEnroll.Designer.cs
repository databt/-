﻿namespace Renew_Library_System
{
    partial class FormEnroll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.StudentID_tbx = new System.Windows.Forms.TextBox();
            this.Tel_tbx = new System.Windows.Forms.TextBox();
            this.AnewPassword_tbx = new System.Windows.Forms.TextBox();
            this.Password_tbx = new System.Windows.Forms.TextBox();
            this.UserName_tbx = new System.Windows.Forms.TextBox();
            this.new_btn = new System.Windows.Forms.Button();
            this.exit_btn = new System.Windows.Forms.Button();
            this.Sex_cbx = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SkyBlue;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(106, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 33);
            this.label2.TabIndex = 2;
            this.label2.Text = "学号";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SkyBlue;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 33);
            this.label1.TabIndex = 3;
            this.label1.Text = "注：账号在创建成功后生成";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.SkyBlue;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(106, 421);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 33);
            this.label3.TabIndex = 4;
            this.label3.Text = "确认密码";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.SkyBlue;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(106, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 33);
            this.label4.TabIndex = 5;
            this.label4.Text = "密码";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.SkyBlue;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(106, 279);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 33);
            this.label5.TabIndex = 6;
            this.label5.Text = "手机号码";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.SkyBlue;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(106, 208);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 33);
            this.label6.TabIndex = 7;
            this.label6.Text = "性别";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.SkyBlue;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(106, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 33);
            this.label7.TabIndex = 8;
            this.label7.Text = "用户名";
            // 
            // StudentID_tbx
            // 
            this.StudentID_tbx.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.StudentID_tbx.Location = new System.Drawing.Point(238, 63);
            this.StudentID_tbx.Name = "StudentID_tbx";
            this.StudentID_tbx.Size = new System.Drawing.Size(221, 40);
            this.StudentID_tbx.TabIndex = 10;
            this.StudentID_tbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.StudentID_tbx_KeyPress);
            // 
            // Tel_tbx
            // 
            this.Tel_tbx.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Tel_tbx.Location = new System.Drawing.Point(238, 275);
            this.Tel_tbx.Name = "Tel_tbx";
            this.Tel_tbx.Size = new System.Drawing.Size(221, 40);
            this.Tel_tbx.TabIndex = 11;
            this.Tel_tbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tel_tbx_KeyPress);
            // 
            // AnewPassword_tbx
            // 
            this.AnewPassword_tbx.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AnewPassword_tbx.Location = new System.Drawing.Point(238, 423);
            this.AnewPassword_tbx.Name = "AnewPassword_tbx";
            this.AnewPassword_tbx.Size = new System.Drawing.Size(221, 40);
            this.AnewPassword_tbx.TabIndex = 12;
            this.AnewPassword_tbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AnewPassword_tbx_KeyPress);
            // 
            // Password_tbx
            // 
            this.Password_tbx.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Password_tbx.Location = new System.Drawing.Point(238, 349);
            this.Password_tbx.Name = "Password_tbx";
            this.Password_tbx.Size = new System.Drawing.Size(221, 40);
            this.Password_tbx.TabIndex = 14;
            this.Password_tbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Password_tbx_KeyPress);
            // 
            // UserName_tbx
            // 
            this.UserName_tbx.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.UserName_tbx.Location = new System.Drawing.Point(238, 135);
            this.UserName_tbx.Name = "UserName_tbx";
            this.UserName_tbx.Size = new System.Drawing.Size(221, 40);
            this.UserName_tbx.TabIndex = 15;
            this.UserName_tbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.UserName_tbx_KeyPress);
            // 
            // new_btn
            // 
            this.new_btn.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.new_btn.Location = new System.Drawing.Point(123, 526);
            this.new_btn.Name = "new_btn";
            this.new_btn.Size = new System.Drawing.Size(85, 42);
            this.new_btn.TabIndex = 16;
            this.new_btn.Text = "创建";
            this.new_btn.UseVisualStyleBackColor = true;
            this.new_btn.Click += new System.EventHandler(this.new_btn_Click);
            // 
            // exit_btn
            // 
            this.exit_btn.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.exit_btn.Location = new System.Drawing.Point(391, 526);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(85, 42);
            this.exit_btn.TabIndex = 17;
            this.exit_btn.Text = "退出";
            this.exit_btn.UseVisualStyleBackColor = true;
            this.exit_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // Sex_cbx
            // 
            this.Sex_cbx.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Sex_cbx.FormattingEnabled = true;
            this.Sex_cbx.Items.AddRange(new object[] {
            "男",
            "女",
            "武装直升机"});
            this.Sex_cbx.Location = new System.Drawing.Point(238, 200);
            this.Sex_cbx.Name = "Sex_cbx";
            this.Sex_cbx.Size = new System.Drawing.Size(221, 41);
            this.Sex_cbx.TabIndex = 18;
            // 
            // FormEnroll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(606, 660);
            this.Controls.Add(this.Sex_cbx);
            this.Controls.Add(this.exit_btn);
            this.Controls.Add(this.new_btn);
            this.Controls.Add(this.UserName_tbx);
            this.Controls.Add(this.Password_tbx);
            this.Controls.Add(this.AnewPassword_tbx);
            this.Controls.Add(this.Tel_tbx);
            this.Controls.Add(this.StudentID_tbx);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Name = "FormEnroll";
            this.Text = "用户注册";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox StudentID_tbx;
        private System.Windows.Forms.TextBox Tel_tbx;
        private System.Windows.Forms.TextBox AnewPassword_tbx;
        private System.Windows.Forms.TextBox Password_tbx;
        private System.Windows.Forms.TextBox UserName_tbx;
        private System.Windows.Forms.Button new_btn;
        private System.Windows.Forms.Button exit_btn;
        private System.Windows.Forms.ComboBox Sex_cbx;
    }
}