﻿namespace Renew_Library_System
{
    partial class FormPersonal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonModify = new System.Windows.Forms.Button();
            this.buttonRemoval = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonAddadmin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonModify
            // 
            this.buttonModify.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonModify.Location = new System.Drawing.Point(32, 420);
            this.buttonModify.Name = "buttonModify";
            this.buttonModify.Size = new System.Drawing.Size(155, 48);
            this.buttonModify.TabIndex = 0;
            this.buttonModify.Text = "修改密码";
            this.buttonModify.UseVisualStyleBackColor = true;
            this.buttonModify.Click += new System.EventHandler(this.buttonModify_Click);
            // 
            // buttonRemoval
            // 
            this.buttonRemoval.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonRemoval.Location = new System.Drawing.Point(416, 420);
            this.buttonRemoval.Name = "buttonRemoval";
            this.buttonRemoval.Size = new System.Drawing.Size(155, 48);
            this.buttonRemoval.TabIndex = 1;
            this.buttonRemoval.Text = "注销";
            this.buttonRemoval.UseVisualStyleBackColor = true;
            this.buttonRemoval.Click += new System.EventHandler(this.buttonRemoval_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(217, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 40);
            this.label1.TabIndex = 2;
            this.label1.Text = "标签";
            // 
            // buttonAddadmin
            // 
            this.buttonAddadmin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonAddadmin.Location = new System.Drawing.Point(224, 420);
            this.buttonAddadmin.Name = "buttonAddadmin";
            this.buttonAddadmin.Size = new System.Drawing.Size(155, 48);
            this.buttonAddadmin.TabIndex = 14;
            this.buttonAddadmin.Text = "添加管理员";
            this.buttonAddadmin.UseVisualStyleBackColor = true;
            this.buttonAddadmin.Click += new System.EventHandler(this.buttonAddadmin_Click);
            // 
            // FormPersonal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 33F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(616, 532);
            this.Controls.Add(this.buttonAddadmin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonRemoval);
            this.Controls.Add(this.buttonModify);
            this.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "FormPersonal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormPersonal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormPersonal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonModify;
        private System.Windows.Forms.Button buttonRemoval;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonAddadmin;
    }
}