﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ulitity;

namespace Renew_Library_System
{
    public partial class FormUser : Form
    {
        private string _name;
        private int _id;
        private string _UorA;
        private Form _form;
        public FormUser(string name, int id, string UorA)
        {
            InitializeComponent();
            _name = name;
            _id = id;
            _UorA = UorA;
        }

        private void FormUser_Load(object sender, EventArgs e)
        {
            _form = FormFactory.CreateForm("FormPersonal",_name,_id,_UorA);
            _form.MdiParent = this;
            _form.Parent = splitContainer1.Panel2;
            _form.Show();
        }

        private void Menu_treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            foreach (TreeNode node in Menu_treeView.Nodes)
            {
                node.BackColor = Color.White;
                node.ForeColor = Color.Black;
            }
            //Menu_trv.SelectedNode；((TreeView)sender).SelectedNode；e.Node
            //这三个能获取到事件触发节点
            e.Node.BackColor = SystemColors.Highlight;
            e.Node.ForeColor = Color.White;

            Form form = FormFactory.CreateForm(e.Node.Tag?.ToString(),_name,_id,_UorA);
            form.MdiParent = this;
            form.Parent = splitContainer1.Panel2;
            form.Show();
        }

        //退出登录
        private void button1_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("是否退出？", "提示",
    MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                FormFactory.FormRemove("FormPersonal");
                this.Close();
            }
        }
    }
}
