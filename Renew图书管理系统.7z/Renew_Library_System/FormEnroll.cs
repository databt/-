﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormEnroll : Form
    {
        public FormEnroll()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void new_btn_Click(object sender, EventArgs e)
        {
            if (StudentID_tbx.Text == "" || UserName_tbx.Text == "" || Tel_tbx.Text == "" ||
    Password_tbx.Text == "" || AnewPassword_tbx.Text == "" || Sex_cbx.Text == "")
            {
                MessageBox.Show("请补全所有信息！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (Password_tbx.Text != AnewPassword_tbx.Text)
            {
                MessageBox.Show("两次密码输入不一致！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string idCard = StudentID_tbx.Text.Trim(); string userName = UserName_tbx.Text.Trim();
            string password = Password_tbx.Text.Trim();
            string sex = Sex_cbx.Text;
            string tel = Tel_tbx.Text;

            Users user = new Users
            {
                IDCard = idCard,
                UserPassword = password,
                Name = userName,
                Sex = sex,
                Tel = tel,
                IsDel = false
            };
            Users.Insert(user);
            int userid = Users.Select(userName);
            MessageBox.Show("用户注册完成！" + Environment.NewLine + $"您的账号是：{userid} 您的密码是：{password}", "消息",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void StudentID_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 判断是否为数字或控制字符（如Backspace）  
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                // 如果是非数字和非控制字符，则忽略该输入  
                e.Handled = true;
            }
        }

        private void UserName_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void Tel_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 判断是否为数字或控制字符（如Backspace）  
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                // 如果是非数字和非控制字符，则忽略该输入  
                e.Handled = true;
            }
        }

        private void Password_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Z0-9]");
            Password_tbx.Text = regex.Replace(Password_tbx.Text, "");
        }

        private void AnewPassword_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Z0-9]");
            Password_tbx.Text = regex.Replace(Password_tbx.Text, "");
        }
    }
}
