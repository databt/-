﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormReturnBook : Form
    {
        private Delbingdgv _delbingdgv;
        private BRNews _brNews;
        private Books _books;
        private int _id;
        public FormReturnBook(int UserID)
        {
            InitializeComponent();
            _id = UserID;
        }

        private void FormReturnBook_Load(object sender, EventArgs e)
        {
            bingcbx();
            bingdgv();
            _delbingdgv = bingdgv;
            int id = (int)News_dgv.SelectedRows[0].Cells["ID"].Value;
            _brNews = BRNews.GetListAllJoinBRNews(_id).Find(m => m.ID == id);
        }
        private void bingcbx()
        {
            List<BookType> booktype = new List<BookType>();
            booktype.AddRange(BookType.ListAll());
            booktype.Insert(0, new BookType
            {
                IDtype = 0,
                TypeName = "-查询所有-"
            });
            type_cbx.DataSource = booktype;
            type_cbx.DisplayMember = "typeName";
            type_cbx.ValueMember = "IDtype";
        }
        private void bingdgv()
        {
            string bookname = BookName_tbx.Text.Trim();
            int typeID = (int)type_cbx.SelectedValue;
            bool isDel = IsDel_check.Checked;
            News_dgv.AutoGenerateColumns = false;
            if (typeID == 0)
            {
                News_dgv.DataSource = BRNews.GetListAllJoinBRNews(_id).FindAll(
m => m.BookName.Contains(bookname) && m.IsDel == isDel);
            }
            else
            {
                News_dgv.DataSource = BRNews.GetListAllJoinBRNews(_id).FindAll(
m => m.BookName.Contains(bookname) && m.TypeID == typeID && m.IsDel == isDel);
            }
        }
        private void Refer_btn_Click(object sender, EventArgs e)
        {
            bingdgv();
        }

        private void Clear_btn_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("是否删除已归还消息？", "消息", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                int a = 0;
                foreach (DataGridViewRow row in News_dgv.Rows)
                {
                    int selectedRowIndex = News_dgv.SelectedRows[0].Index;
                    bool isdel = Convert.ToBoolean(News_dgv.Rows[selectedRowIndex].Cells["IsDel"].Value);
                    if (isdel == true) { a++; BRNews.Delete(_brNews); }
                }
                if(a != 0)
                {
                    MessageBox.Show("归还记录已删除", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    bingdgv();
                }
                else
                {
                    MessageBox.Show("没有要删除的归还记录！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                return;
            }
        }

        private void 归还ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("是否归还？", "消息", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                int selectedRowIndex = News_dgv.SelectedRows[0].Index;
                bool isdel = Convert.ToBoolean(News_dgv.Rows[selectedRowIndex].Cells["IsDel"].Value);
                string bookname = Convert.ToString(News_dgv.Rows[selectedRowIndex].Cells["BookName"].Value);
                if (isdel == false)
                {
                    _brNews.IsDel = true;
                    BRNews.Update(_brNews);
                    _books = Books.GetListJoinBook().Find(x => x.Name == bookname);
                    _books.Num += 1;
                    _books.BorrowCount -= 1;
                    Books.Update1(_books);
                    MessageBox.Show("图书归还成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    bingdgv();
                }
                else { MessageBox.Show("图书已归还", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            }
            else
            {
                return;
            }
        }

        private void News_dgv_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex > -1)
                {
                    News_dgv.ClearSelection();
                    //锁定选中的一行
                    News_dgv.Rows[e.RowIndex].Selected = true;
                    归还ToolStripMenuItem.Visible = true;
                }
                int selectedRowIndex = News_dgv.SelectedRows[0].Index;
                bool isdel = Convert.ToBoolean(News_dgv.Rows[selectedRowIndex].Cells["IsDel"].Value);
                if (isdel == true)
                {
                    归还ToolStripMenuItem.Visible = false;
                }
            }
        }

        private void News_dgv_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                归还ToolStripMenuItem.Visible = false;
            }
        }
    }
}
