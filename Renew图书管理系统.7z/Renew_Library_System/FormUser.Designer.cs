﻿namespace Renew_Library_System
{
    partial class FormUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("个人信息管理");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("租借管理");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("图书评价");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("系统反馈");
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.button1 = new System.Windows.Forms.Button();
            this.Menu_treeView = new System.Windows.Forms.TreeView();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button1);
            this.splitContainer1.Panel1.Controls.Add(this.Menu_treeView);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.Azure;
            this.splitContainer1.Size = new System.Drawing.Size(1158, 765);
            this.splitContainer1.SplitterDistance = 262;
            this.splitContainer1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(19, 553);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 57);
            this.button1.TabIndex = 3;
            this.button1.Text = "退出登录";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Menu_treeView
            // 
            this.Menu_treeView.BackColor = System.Drawing.Color.Azure;
            this.Menu_treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Menu_treeView.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Menu_treeView.ItemHeight = 55;
            this.Menu_treeView.Location = new System.Drawing.Point(0, 0);
            this.Menu_treeView.Name = "Menu_treeView";
            treeNode1.Name = "Personal";
            treeNode1.Tag = "FormPersonal";
            treeNode1.Text = "个人信息管理";
            treeNode2.Name = "LeaseManagement";
            treeNode2.Tag = "FormBorrow";
            treeNode2.Text = "租借管理";
            treeNode3.Name = "Reviews";
            treeNode3.Tag = "FormComment";
            treeNode3.Text = "图书评价";
            treeNode4.Name = "Feedback";
            treeNode4.Tag = "FormFeekback";
            treeNode4.Text = "系统反馈";
            this.Menu_treeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4});
            this.Menu_treeView.Size = new System.Drawing.Size(262, 765);
            this.Menu_treeView.TabIndex = 0;
            this.Menu_treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.Menu_treeView_AfterSelect);
            // 
            // FormUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1158, 765);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.Name = "FormUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormUser";
            this.Load += new System.EventHandler(this.FormUser_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView Menu_treeView;
        private System.Windows.Forms.Button button1;
    }
}