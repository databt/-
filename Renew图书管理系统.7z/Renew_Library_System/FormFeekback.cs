﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormFeekback : Form
    {
        private int _uid;
        public FormFeekback(int id)
        {
            InitializeComponent();
            _uid = id;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            //限制两百字
            int num = 200;
            if (richTextBox1.TextLength > num + 1)
            {
                // 如果超过限制，则移除多余的字符  
                richTextBox1.Text = richTextBox1.Text.Substring(0, num);

                // 可以选择性地设置光标位置到文本末尾  
                richTextBox1.SelectionStart = richTextBox1.TextLength;
                richTextBox1.ScrollToCaret();

                MessageBox.Show("字符数已达到最大限制（" + num + "字符）");
            }
        }

        private void submit_btn_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text.Trim().Length > 0)
            {
                Feedback feedback = new Feedback
                {
                    Time = DateTime.Now,
                    feedback = richTextBox1.Text.Trim(),
                    Uid = _uid
                };
                Feedback.Insert(feedback);
                MessageBox.Show("反馈成功","消息",MessageBoxButtons.OK, MessageBoxIcon.Information);
                richTextBox1.Text = null;
            }
        }

        private void FormFeekback_Load(object sender, EventArgs e)
        {

        }
    }
}
