﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Ulitity;

namespace Renew_Library_System
{
    public delegate void DelPersonal(string name, int id, string uorA);
    public partial class FormAdmin : Form
    {
        private string _Name;
        private int _Id;
        private string _UorA;
        private Form _form;
        public FormAdmin(string name, int id, string uorA)
        {
            InitializeComponent();
            _Name = name;
            _Id = id;
            _UorA = uorA;
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {
            _form = FormFactory.CreateForm("FormPersonal", _Name, _Id, _UorA);
            _form.MdiParent = this;
            _form.Parent = splitContainer1.Panel2;
            _form.Show();
        }

        private void Menu_treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            foreach (TreeNode node in Menu_treeView.Nodes)
            {
                node.BackColor = Color.White;
                node.ForeColor = Color.Black;
            }
            //Menu_trv.SelectedNode；((TreeView)sender).SelectedNode；e.Node
            //这三个能获取到事件触发节点
            e.Node.BackColor = SystemColors.Highlight;
            e.Node.ForeColor = Color.White;

            //工厂模式实现窗体之间切换(除了代码引用外，还要在控件中添加tag标签）
            Form form = FormFactory.CreateForm(e.Node.Tag?.ToString(), _Name, _Id, _UorA);
            form.MdiParent = this;
            form.Parent = splitContainer1.Panel2;
            form.Show();
        }

        //退出登录
        private void button1_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("是否退出？", "提示",
    MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                FormFactory.FormRemove("FormPersonal");
                this.Close();
            }
        }
    }
}
