﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormPubComment : Form
    {
        private string _Bname;
        private string _name;
        private int _id;
        public FormPubComment(string Bname,string name,int id)
        {
            InitializeComponent();
            _Bname = Bname;
            _name = name;
            _id = id;
            Bname_tbx.Text = _Bname;
        }


        private void close_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Pub_btn_Click(object sender, EventArgs e)
        {
            if (!(comment_rtb.Text.Trim().Length > 0 || num_tbx.Text.Length > 0))
            {
                MessageBox.Show("评论或评分不能空！！！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Comment comment = new Comment
                { 
                    Time = DateTime.Now,
                    Bid = Books.Select(_Bname),
                    Bname = _Bname,
                    Uid= _id,
                    Uname= _name,
                    Score = Convert.ToInt32(num_tbx.Text.Trim()),
                    Words = comment_rtb.Text.Trim()
                };
                Comment.Insert(comment);
                if(comment.Words != null)
                {
                    MessageBox.Show("发表评论成功！！！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("发表评论失败，请稍后再试！！！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void num_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            Regex regex = new Regex("[^1-5]");
            num_tbx.Text = regex.Replace(num_tbx.Text, "");
        }

        private void comment_rtb_TextChanged(object sender, EventArgs e)
        {
            //限制两百字
            int num = 200;
            if (comment_rtb.TextLength > num+1)
            {
                // 如果超过限制，则移除多余的字符  
                comment_rtb.Text = comment_rtb.Text.Substring(0, num);

                // 可以选择性地设置光标位置到文本末尾  
                comment_rtb.SelectionStart = comment_rtb.TextLength;
                comment_rtb.ScrollToCaret();

                MessageBox.Show("字符数已达到最大限制（" + num + "字符）");
            }
        }
    }
}
