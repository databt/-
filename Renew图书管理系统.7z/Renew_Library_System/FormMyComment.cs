﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Renew_Library_System
{
    public partial class FormMyComment : Form
    {
        private string _uname;
        public FormMyComment(string uname)
        {
            InitializeComponent();
            _uname = uname;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormMyComment_Load(object sender, EventArgs e)
        {
            bingcbx();
            bingdgv();
        }

        private void bingdgv()
        {
            string bookname = Bname_tbx.Text.Trim();
            string Uname = _uname;
            int typeID = (int)type_cbx.SelectedValue;
            MyComments_dgv.AutoGenerateColumns = false;
            if (typeID == 0)
            {
                MyComments_dgv.DataSource = Comment.GetListAllJoinComment().FindAll(
m => m.Bname.Contains(bookname) && m.Uname == Uname);
            }
            else
            {
                MyComments_dgv.DataSource = Comment.GetListAllJoinComment().FindAll(
m => m.Bname.Contains(bookname) && m.Uname == Uname && m.typeID == typeID);
            }
        }

        private void bingcbx()
        {
            List<BookType> booktype = new List<BookType>();
            booktype.AddRange(BookType.ListAll());
            booktype.Insert(0, new BookType
            {
                IDtype = 0,
                TypeName = "-查询所有-"
            });
            type_cbx.DataSource = booktype;
            type_cbx.DisplayMember = "typeName";
            type_cbx.ValueMember = "IDtype";
        }

        private void Refer_btn_Click(object sender, EventArgs e)
        {
            bingdgv();
        }

        private void 删除评论ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(MyComments_dgv.SelectedRows[0].Cells["id"].Value);
            Comment.Delete(id);
            MessageBox.Show("评论已删除","消息",MessageBoxButtons.OK, MessageBoxIcon.Information);
            bingdgv();
        }
    }
}
