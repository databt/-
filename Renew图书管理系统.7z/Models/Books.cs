﻿using Ulitity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Books
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }
        public DateTime PBdate { get; set; }
        public int TypeID { get; set; }
        public string TypeName { get; set; }
        public double Price { get; set; }
        public int Num { get; set; }
        public string Introduce { get; set; }
        public int BorrowCount { get; set; }
        public bool IsDel { get; set; }

        //这里拆成datable先获取，再赋给list，为了方便程序内调用datable。list集合不好加属性，所以不好做成动态扩展
        public static DataTable GetDataTableJoinBook()
        {
            return SqlHelper.ExecuteTable
                ("select u.ID,u.Name,u.Author,u.Publisher,u.PBdate,u.TypeID,a.typeName,u.Price,u.Num," +
                "u.introduce,u.BorrowCount,u.IsDel from 图书库 u Left join 图书类型库 a on u.TypeID = a.IDtype");
        }
        public static List<Books> GetListJoinBook()
        {
            List<Books> books = new List<Books>();
            DataTable dt = GetDataTableJoinBook();
            foreach (DataRow dr in dt.Rows)
            {
                books.Add(dr.DataRowToModel<Books>());
            }
            return books;
        }
        //添加数据
        public static int Insert(Books book)
        {
            return SqlHelper.ExecuteNonQuery($"INSERT INTO 图书库(Name,Author,Publisher,PBdate,TypeID,Price,Num,Introduce,BorrowCount,IsDel) " +
                $"VALUES (@Name,@Author,@Publisher,@PBdate,@TypeID,@Price,@Num,@Introduce,@BorrowCount,@IsDel)",
                new SqlParameter("@Name", book.Name),
                new SqlParameter("@Author", book.Author),
                new SqlParameter("@Publisher", book.Publisher),
                new SqlParameter("@PBdate", book.PBdate),
                new SqlParameter("@TypeID", book.TypeID),
                //new SqlParameter("@TypeName", book.TypeName),
                new SqlParameter("@Price", book.Price),
                new SqlParameter("@Num", book.Num),
                new SqlParameter("@Introduce", book.Introduce),
                new SqlParameter("@BorrowCount", book.BorrowCount),
                new SqlParameter("@IsDel", book.IsDel)
                );
        }
        //查找
        public static int Select(string name)
        {
            int id = 0;
            DataTable dt = SqlHelper.ExecuteTable("select ID,Name from 图书库");
            foreach (DataRow dr in dt.Rows)
            {
                if (name == dr["Name"].ToString())
                {
                    id = (int)dr["ID"];
                }
            }
            return id;
        }
        public static bool SelectBook(string name)
        {
            DataTable dt = SqlHelper.ExecuteTable("select * from 图书库 Where Num = BorrowCount");
            foreach (DataRow dr in dt.Rows)
            {
                if (name == dr["Name"].ToString())
                {
                    return true;
                }
            }
            return false;
        }
        public static int Edit(Books book)
        {
            return SqlHelper.ExecuteNonQuery("Update 图书库 set IsDel=@IsDel where ID=@ID",
                new SqlParameter("@IsDel", book.IsDel),
                new SqlParameter("@ID", book.Id));
        }
        //public static int Delete(Books book)
        //{
        //    return SqlHelper.ExecuteNonQuery("delete from 图书库 where Id = @Id",
        //        new SqlParameter("@Id", book.Id));
        //}

        public static int Update(Books book)
        {
            return SqlHelper.ExecuteNonQuery($"UPDATE 图书库 SET Name=@Name,Author=@Author,Publisher=@Publisher,PBdate=@PBdate," +
                $"TypeID=@TypeID,Price=@Price,Num=@Num,Introduce=@Introduce,BorrowCount=@BorrowCount,IsDel=@IsDel WHERE ID=@ID",
                new SqlParameter("@Name", book.Name),
                new SqlParameter("@Author", book.Author),
                new SqlParameter("@Publisher", book.Publisher),
                new SqlParameter("@PBdate", book.PBdate),
                new SqlParameter("@TypeID", book.TypeID),
                new SqlParameter("@Price", book.Price),
                new SqlParameter("@Num", book.Num),
                new SqlParameter("@Introduce", book.Introduce),
                new SqlParameter("BorrowCount", book.BorrowCount),
                new SqlParameter("@IsDel", book.IsDel),
                new SqlParameter("@ID", book.Id)
                );
        }
        public static int Update1(Books book)
        {
            return SqlHelper.ExecuteNonQuery($"UPDATE 图书库 SET " +
                $"Num=@Num,BorrowCount=@BorrowCount WHERE Name=@Name",
                new SqlParameter("@Name", book.Name),
                new SqlParameter("@Num", book.Num),
                new SqlParameter("BorrowCount", book.BorrowCount)
                );
        }
    }
}
