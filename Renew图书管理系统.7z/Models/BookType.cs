﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Ulitity;

namespace Models
{
    public class BookType
    {
        public int IDtype { get; set; }
        public string TypeName { get; set; }

        public static List<BookType> ListAll()
        {
            List<BookType> booktype = new List<BookType>();
            DataTable dt = SqlHelper.ExecuteTable("SELECT * FROM 图书类型库");
            foreach (DataRow dr in dt.Rows)
            {
                booktype.Add(dr.DataRowToModel<BookType>());
            }
            return booktype;
        }

        public static int Insert(BookType booktype)
        {
            return SqlHelper.ExecuteNonQuery($"INSERT INTO 图书类型库(typeName) " +
                $"VALUES (@TypeName)",
                new SqlParameter("@TypeName", booktype.TypeName)
                );
        }

        public static int Select(string type)
        {
            int id = 0;
            DataTable dt = SqlHelper.ExecuteTable($"select * from 图书类型库");
            foreach (DataRow dr in dt.Rows)
            {
                if (type == dr["TypeName"].ToString())
                {
                    id = (int)dr["IDtype"];
                }
            }
            return id;

        }
    }
}
