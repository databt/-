﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ulitity;
using System.Xml.Linq;

namespace Models
{
    public class Admins
    {
        public string Name { get; set; }
        public string Adminpassword { get; set; }
        public int AdminID { get; set; }

        public static List<Admins> ListAll()
        {
            List<Admins> admins = new List<Admins>();
            DataTable dt = SqlHelper.ExecuteTable("SELECT u.Name ,u.Adminpassword,u.AdminID FROM 管理员库 u ");
            foreach (DataRow dr in dt.Rows)
            {
                admins.Add(dr.DataRowToModel<Admins>());
            }
            return admins;
        }
        //添加数据
        public static int Insert(Admins admin)
        {
            //参数化
            return SqlHelper.ExecuteNonQuery($"INSERT INTO 管理员库(Name,Adminpassword,AdminID) " +
                $"VALUES (@Name,@AdminPassword,@AdminID)",
                new SqlParameter("@Name", admin.Name),
                new SqlParameter("@Adminpassword", admin.Adminpassword),
                new SqlParameter("@AdminID", admin.AdminID)
                );
        }
        public static int Update(Admins admin)
        {
            return SqlHelper.ExecuteNonQuery($"UPDATE 管理员库 SET Name=@Name,Adminpassword=@Adminpassword " +
                $"WHERE AdminID=@AdminID",
                new SqlParameter("@Name", admin.Name),
                new SqlParameter("@Adminpassword", admin.Adminpassword),
                new SqlParameter("@AdminID", admin.AdminID));
        }
        public static int Delete(Admins admin)
        {
            return SqlHelper.ExecuteNonQuery("delete from 管理员库 where AdminID = @AdminID",
                new SqlParameter("@AdminID", admin.AdminID));
        }

        public static int Select(string name)
        {
            return SqlHelper.ExecuteNonQuery("select Adminpassword from 管理员库 where Name=@Name",
                new SqlParameter("@Name", name));
        }

        public static bool Select(int id,string pw)
        {
            DataTable dt = SqlHelper.ExecuteTable("select AdminID,Adminpassword from 管理员库");
            foreach (DataRow dr in dt.Rows)
            {
                if (id == (int)dr["AdminID"] && pw == dr["Adminpassword"].ToString())
                {
                    return true;
                }
            }
            return false;
        }
    }
}
