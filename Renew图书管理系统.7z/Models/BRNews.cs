﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Ulitity;

namespace Models
{
    public class BRNews
    {
        public int ID { get; set; }
        public int UserID { get; set; }
        public string BookName { get; set; }
        public int TypeID { get; set; }
        public string TypeName { get; set; }
        public int Num { get; set; }
        public DateTime NewTime { get; set; }
        public bool IsDel { get; set; }
        //public string Name { get; set; }

        public static DataTable GetDataTableJoinBook(int id)
        {
            return SqlHelper.ExecuteTable("SELECT u.ID,u.UserID,u.BookName,u.TypeID,a.typeName," +
                "u.Num,u.NewTime,u.IsDel FROM 租借记录库 u left join 图书类型库 a on u.TypeID = a.IDtype " +
                "Where UserID = @id",
                new SqlParameter("@id", id));
        }
        public static List<BRNews> GetListAllJoinBRNews(int id)
        {
            List<BRNews> bRNews = new List<BRNews>();
            DataTable dt = GetDataTableJoinBook(id);
            foreach (DataRow dr in dt.Rows)
            {
                bRNews.Add(dr.DataRowToModel<BRNews>());
            }
            return bRNews;
        }

//        public static DataTable GetDataTableJoinLookUser(int id)
//        {
//            return SqlHelper.ExecuteTable("select u.name,b.UserID,b.BookName,a.typeName,b.Num,b.NewTime,b.IsDel "+
//"from 租借记录库 b inner join 图书类型库 a on a.IDtype = b.TypeID inner join 用户库 u on u.UserID = b.UserID"+
//                "Where UserID = @id",
//                new SqlParameter("@id", id));
//        }
//        public static List<BRNews> GetListAllJoinLookUser(int id)
//        {
//            List<BRNews> bRNews = new List<BRNews>();
//            DataTable dt = GetDataTableJoinBook(id);
//            foreach (DataRow dr in dt.Rows)
//            {
//                bRNews.Add(dr.DataRowToModel<BRNews>());
//            }
//            return bRNews;
//        }
        public static int Insert(BRNews bRNews)
        {
            return SqlHelper.ExecuteNonQuery($"INSERT INTO 租借记录库(UserID,BookName,TypeID,Num,NewTime,IsDel) " +
                $"VALUES (@UserID,@BookName,@TypeID,@Num,@NewTime,@IsDel)",
                new SqlParameter("@UserID", bRNews.UserID),
                new SqlParameter("@BookName", bRNews.BookName),
                new SqlParameter("@TypeID", bRNews.TypeID),
                new SqlParameter("@Num", bRNews.Num),
                new SqlParameter("@NewTime", bRNews.NewTime),
                new SqlParameter("@IsDel", bRNews.IsDel)
                );
        }

        public static int Delete(BRNews bRNews)
        {
            return SqlHelper.ExecuteNonQuery("delete from 租借记录库 where IsDel = 1",
                new SqlParameter("@IsDel", bRNews.IsDel));
        }

        public static bool Select(int id, string bookname)
        {
            DataTable dt = SqlHelper.ExecuteTable("select UserID,BookName,IsDel from 租借记录库");
            foreach (DataRow dr in dt.Rows)
            {
                if (id == (int)dr["UserID"] && bookname == (string)dr["BookName"] && !(bool)dr["IsDel"])
                {
                    return true;
                }
            }
            return false;
        }

        public static int Update(BRNews bRnews)
        {
            return SqlHelper.ExecuteNonQuery($"UPDATE 租借记录库 SET IsDel=@IsDel WHERE ID=@ID",
                new SqlParameter("@ID", bRnews.ID),
                new SqlParameter("@IsDel", bRnews.IsDel));
        }

        public static bool Select(int id)
        {
            int num = 0;
            DataTable dt = SqlHelper.ExecuteTable($"Select UserID from 租借记录库");
            foreach (DataRow dr in dt.Rows)
            {
                if (id == (int)dr["UserID"])
                {
                    num++;
                }
            }
            if (num > 0)
            {
                return true;
            }
            return false;
        }
    }
}
