﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ulitity;

namespace Models
{
    public class LookUser
    {
        public string Name { get; set; }
        public int UserID { get; set; }
        public string BookName { get; set; }
        public int IDtype { get; set; }
        public string typeName { get; set; }
        public int Num {  get; set; }
        public DateTime NewTime { get; set; }
        public bool IsDel {  get; set; }

        public static DataTable GetDataTableJoinLookUser()
        {
            return SqlHelper.ExecuteTable("select u.name,b.UserID,b.BookName,a.IDtype,a.typeName,b.Num,b.NewTime,b.IsDel " +
"from 租借记录库 b inner join 图书类型库 a on a.IDtype = b.TypeID inner join 用户库 u on u.UserID = b.UserID");
        }
        public static List<LookUser> GetListAllJoinLookUser()
        {
            List<LookUser> lookUsers = new List<LookUser>();
            DataTable dt = GetDataTableJoinLookUser();
            foreach (DataRow dr in dt.Rows)
            {
                lookUsers.Add(dr.DataRowToModel<LookUser>());
            }
            return lookUsers;
        }
    }
}
