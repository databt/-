﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ulitity;

namespace Models
{
    public class Feedback
    {
        public int Uid { get; set; }
        public string feedback { get; set; }
        public DateTime Time { get; set; }

        public static List<Feedback> GetListAllJoinFeedback()
        {
            List<Feedback> feedbacks = new List<Feedback>();
            DataTable dt = GetTableJoinFeedback();
            foreach (DataRow dr in dt.Rows)
            {
                feedbacks.Add(dr.DataRowToModel<Feedback>());
            }
            return feedbacks;
        }

        private static DataTable GetTableJoinFeedback()
        {
            return SqlHelper.ExecuteTable("select * from 反馈库");
        }

        public static int Insert(Feedback feedback)
        {
            return SqlHelper.ExecuteNonQuery($"INSERT INTO 反馈库(Uid,Feedback,Time)" +
                $"Values(@Uid,@Feedback,@Time)",
                new SqlParameter("@Uid", feedback.Uid),
                new SqlParameter("@Feedback", feedback.feedback),
                new SqlParameter("@Time", feedback.Time));

        }
        public static int Delete(DateTime dt)
        {
            return SqlHelper.ExecuteNonQuery("Delete from 反馈库 where Time = @dt",
                new SqlParameter("@dt",dt));

        }
    }
}
