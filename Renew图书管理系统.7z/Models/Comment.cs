﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ulitity;

namespace Models
{
    public class Comment
    {
        public int Id { get; set; }
        public int Bid { get; set; }
        public string Bname { get; set; }
        public int Uid { get; set; }
        public string Uname { get; set; }
        public string Words { get; set; }
        public DateTime Time { get; set; }
        public int Score { get; set; }
        public int typeID { get; set; }

        public static List<Comment> GetListAllJoinComment()
        {
            List<Comment> comment = new List<Comment>();
            DataTable dt = GetDataTableJoinUsers();
            foreach (DataRow dr in dt.Rows)
            {
                comment.Add(dr.DataRowToModel<Comment>());
            }
            return comment;
        }

        private static DataTable GetDataTableJoinUsers()
        {
            return SqlHelper.ExecuteTable("select a.*,b.TypeID from 评论库 a Left join 图书库 b on a.Bname = b.Name");
        }

        public static int Insert(Comment comment)
        {
            return SqlHelper.ExecuteNonQuery($"INSERT INTO 评论库(Bid,Bname,Uid,Uname,Words,Time,Score)" +
                $"Values(@Bid,@Bname,@Uid,@Uname,@Words,@Time,@Score)",
                new SqlParameter("@Bid",comment.Bid),
                new SqlParameter("@Bname",comment.Bname),
                new SqlParameter("@Uid",comment.Uid),
                new SqlParameter("@Uname", comment.Uname),
                new SqlParameter("@Words", comment.Words),
                new SqlParameter("@Time", comment.Time),
                new SqlParameter("@Score", comment.Score));
        }

        public static int Delete(int id)
        {
            return SqlHelper.ExecuteNonQuery($"delete from 评论库 where id = @id",
                new SqlParameter("@id",id));
        }
    }
}
