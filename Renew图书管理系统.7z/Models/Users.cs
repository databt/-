﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ulitity;

namespace Models
{
    public class Users
    {
        public int UserID { get; set; }
        public string UserPassword { get; set; }
        public string Name { get; set; }
        public string Sex { get; set; }
        public string IDCard { get; set; }
        public string Tel { get; set; }
        public bool IsDel { get; set; }

        public static List<Users> ListAll()
        {
            List<Users> users = new List<Users>();
            DataTable dt = SqlHelper.ExecuteTable("SELECT * FROM 用户库");
            foreach (DataRow dr in dt.Rows)
            {
                users.Add(dr.DataRowToModel<Users>());
            }
            return users;
        }


        public static List<Users> GetListAllJoinUsers()
        {
            List<Users> users = new List<Users>();
            DataTable dt = GetDataTableJoinUsers();
            foreach (DataRow dr in dt.Rows)
            {
                users.Add(dr.DataRowToModel<Users>());
            }
            return users;
        }

        private static DataTable GetDataTableJoinUsers()
        {
            return SqlHelper.ExecuteTable("SELECT * FROM 用户库");
        }

        //添加数据
        public static int Insert(Users user)
        {
            //参数化
            return SqlHelper.ExecuteNonQuery($"INSERT INTO 用户库(UserPassword,Name,Sex,IDCard,Tel,IsDel) " +
                $"VALUES (@UserPassword,@Name,@Sex,@IDCard,@Tel,@IsDel)",
                new SqlParameter("@UserPassword", user.UserPassword),
                new SqlParameter("@Name", user.Name),
                new SqlParameter("@Sex", user.Sex),
                new SqlParameter("@IDCard", user.IDCard),
                new SqlParameter("@Tel", user.Tel),
                new SqlParameter("@IsDel", user.IsDel)
                );
        }
        //查找
        public static int Select(string name)
        {
            int id = 0;
            DataTable dt = SqlHelper.ExecuteTable("select UserID,Name from 用户库");
            foreach (DataRow dr in dt.Rows)
            {
                if (name == dr["name"].ToString())
                {
                    id = (int)dr["UserID"];
                }
            }
            return id;
        }
        public static bool Select(string name, int id)
        {
            DataTable dt = SqlHelper.ExecuteTable("select UserID,Name from 用户库");
            foreach (DataRow dr in dt.Rows)
            {
                if (id == (int)dr["UserID"] && name == dr["Name"].ToString())
                {
                    return true;
                }
            }
            return false;
        }
        public static bool Select(int id,string pw)
        {
            DataTable dt = SqlHelper.ExecuteTable("select UserID,UserPassword from 用户库");
            foreach (DataRow dr in dt.Rows)
            {
                if (id == (int)dr["UserID"] && pw == (string)dr["UserPassword"])
                {
                    return true;
                }
            }
            return false;
        }
        public static int Delete(Users user)
        {
            return SqlHelper.ExecuteNonQuery("delete from 用户库 where UserID = @UserID",
                new SqlParameter("@UserID", user.UserID));
        }

        public static int Update(Users user)
        {
            return SqlHelper.ExecuteNonQuery($"UPDATE 用户库 SET Name=@Name," +
                $"UserPassword=@UserPassword,Sex=@Sex,IDCard=@IDCard,Tel=@Tel WHERE UserID=@UserID",
                new SqlParameter("@UserPassword", user.UserPassword),
                new SqlParameter("@Name", user.Name),
                new SqlParameter("@Sex", user.Sex),
                new SqlParameter("@IDCard", user.IDCard),
                new SqlParameter("@Tel", user.Tel),
                new SqlParameter("@IsDel", user.IsDel),
                new SqlParameter("@UserID", user.UserID));
        }

        public static int DisableorEnable(string name,int userid,bool isdel)
        {
            return SqlHelper.ExecuteNonQuery($"Update 用户库 set Isdel = @Isdel where Name = @Name And UserID = @UserID",
                new SqlParameter("@Isdel",isdel),
                new SqlParameter("@Name",name),
                new SqlParameter("@UserID",userid));
        }
    }
}
